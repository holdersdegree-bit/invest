import { NextResponse } from 'next/server';
import { db } from '@/db';
import { users } from '@/db/schema';
import { verifyPassword, generateToken, hasActiveSubscription } from '@/lib/auth';
import { eq, or } from 'drizzle-orm';
import { cookies } from 'next/headers';

export async function POST(request: Request) {
  try {
    const { identifier, password } = await request.json();

    if (!identifier || !password) {
      return NextResponse.json(
        { error: 'Email/Phone and password are required' },
        { status: 400 }
      );
    }

    // Find user by email or phone
    const userResults = await db
      .select()
      .from(users)
      .where(or(eq(users.email, identifier), eq(users.phone, identifier)))
      .limit(1);

    if (userResults.length === 0) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      );
    }

    const user = userResults[0];

    if (!user.passwordHash) {
      return NextResponse.json(
        { error: 'Please use OTP login' },
        { status: 401 }
      );
    }

    const isValidPassword = await verifyPassword(password, user.passwordHash);
    if (!isValidPassword) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      );
    }

    const isSubscribed = hasActiveSubscription({
      isActive: user.isActive || false,
      subscriptionEnd: user.subscriptionEnd || null,
      isAdmin: user.isAdmin || false,
    });

    const token = generateToken({
      userId: user.id,
      email: user.email,
      phone: user.phone,
      name: user.name,
      isAdmin: user.isAdmin,
      isActive: user.isActive,
      subscriptionEnd: user.subscriptionEnd,
    });

    const cookieStore = await cookies();
    cookieStore.set('prawing_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60, // 30 days
      path: '/',
    });

    return NextResponse.json({
      message: 'Login successful',
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        isAdmin: user.isAdmin,
        isActive: user.isActive,
        subscriptionEnd: user.subscriptionEnd,
        isSubscribed,
      },
      requiresPayment: !isSubscribed && !user.isAdmin,
    });
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
