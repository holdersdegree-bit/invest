import { NextResponse } from 'next/server';
import { db } from '@/db';
import { otpCodes, users } from '@/db/schema';
import { generateOTP, isAdminPhone } from '@/lib/auth';
import { eq } from 'drizzle-orm';

export async function POST(request: Request) {
  try {
    const { phone } = await request.json();

    if (!phone) {
      return NextResponse.json(
        { error: 'Phone number is required' },
        { status: 400 }
      );
    }

    const cleanPhone = phone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      return NextResponse.json(
        { error: 'Invalid phone number' },
        { status: 400 }
      );
    }

    // Check if admin phone
    const isAdmin = isAdminPhone(cleanPhone);

    // For non-admin, check if user exists
    if (!isAdmin) {
      const existingUser = await db.select().from(users).where(eq(users.phone, cleanPhone)).limit(1);
      if (existingUser.length === 0) {
        return NextResponse.json(
          { error: 'Phone number not registered. Please sign up first.' },
          { status: 404 }
        );
      }
    }

    // Generate OTP
    const code = generateOTP();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Invalidate old OTPs for this phone
    await db.update(otpCodes).set({ used: true }).where(eq(otpCodes.phone, cleanPhone));

    // Store new OTP
    await db.insert(otpCodes).values({
      phone: cleanPhone,
      code,
      expiresAt,
    });

    // In production, send actual SMS via provider like Twilio, MSG91, etc.
    // For demo, we'll return the OTP in response (NOT for production!)
    console.log(`[DEMO] OTP for ${cleanPhone}: ${code}`);

    return NextResponse.json({
      message: `OTP sent to ${cleanPhone}`,
      isAdmin,
      // Remove this in production - only for demo
      demoOtp: code,
    });
  } catch (error) {
    console.error('Send OTP error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
