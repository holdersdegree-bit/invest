import { NextResponse } from 'next/server';
import { db } from '@/db';
import { otpCodes, users } from '@/db/schema';
import { generateToken, isAdminPhone, hasActiveSubscription } from '@/lib/auth';
import { eq, and, gt } from 'drizzle-orm';
import { cookies } from 'next/headers';

export async function POST(request: Request) {
  try {
    const { phone, code } = await request.json();

    if (!phone || !code) {
      return NextResponse.json(
        { error: 'Phone number and OTP are required' },
        { status: 400 }
      );
    }

    const cleanPhone = phone.replace(/\D/g, '');
    const isAdmin = isAdminPhone(cleanPhone);

    // Find valid OTP
    const now = new Date();
    const otpResults = await db
      .select()
      .from(otpCodes)
      .where(
        and(
          eq(otpCodes.phone, cleanPhone),
          eq(otpCodes.code, code),
          eq(otpCodes.used, false),
          gt(otpCodes.expiresAt, now)
        )
      )
      .orderBy(otpCodes.createdAt)
      .limit(1);

    if (otpResults.length === 0) {
      return NextResponse.json(
        { error: 'Invalid or expired OTP' },
        { status: 401 }
      );
    }

    // Mark OTP as used
    await db.update(otpCodes).set({ used: true }).where(eq(otpCodes.id, otpResults[0].id));

    let user;

    if (isAdmin) {
      // Create admin user if not exists
      const existingAdmin = await db.select().from(users).where(eq(users.phone, cleanPhone)).limit(1);

      if (existingAdmin.length === 0) {
        const newAdmin = await db.insert(users).values({
          name: 'PRAWING Admin',
          email: 'admin@prawing.com',
          phone: cleanPhone,
          isAdmin: true,
          isActive: true,
        }).returning();
        user = newAdmin[0];
      } else {
        user = existingAdmin[0];
        // Ensure admin is always active
        if (!user.isActive || !user.isAdmin) {
          await db.update(users).set({ isActive: true, isAdmin: true }).where(eq(users.id, user.id));
          user = { ...user, isActive: true, isAdmin: true };
        }
      }
    } else {
      // Find existing user
      const userResults = await db.select().from(users).where(eq(users.phone, cleanPhone)).limit(1);
      if (userResults.length === 0) {
        return NextResponse.json(
          { error: 'User not found' },
          { status: 404 }
        );
      }
      user = userResults[0];
    }

    const isSubscribed = hasActiveSubscription({
      isActive: user.isActive || false,
      subscriptionEnd: user.subscriptionEnd || null,
      isAdmin: user.isAdmin || false,
    });

    const token = generateToken({
      userId: user.id,
      email: user.email,
      phone: user.phone,
      name: user.name,
      isAdmin: user.isAdmin,
      isActive: user.isActive,
      subscriptionEnd: user.subscriptionEnd,
    });

    const cookieStore = await cookies();
    cookieStore.set('prawing_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60, // 30 days
      path: '/',
    });

    return NextResponse.json({
      message: isAdmin ? 'Admin login successful' : 'OTP verified successfully',
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        isAdmin: user.isAdmin,
        isActive: user.isActive,
        subscriptionEnd: user.subscriptionEnd,
        isSubscribed,
      },
      isAdmin,
      requiresPayment: !isSubscribed && !user.isAdmin,
    });
  } catch (error) {
    console.error('Verify OTP error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
