import { NextResponse } from 'next/server';
import { db } from '@/db';
import { payments, users } from '@/db/schema';
import { getCurrentUser, SUBSCRIPTION_DURATION_DAYS } from '@/lib/auth';
import { eq } from 'drizzle-orm';

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { paymentMethod, transactionId } = await request.json();

    if (!paymentMethod) {
      return NextResponse.json(
        { error: 'Payment method is required' },
        { status: 400 }
      );
    }

    // Calculate subscription end date
    const now = new Date();
    const subscriptionEnd = new Date(now);
    subscriptionEnd.setDate(subscriptionEnd.getDate() + SUBSCRIPTION_DURATION_DAYS);

    // Create payment record
    const payment = await db.insert(payments).values({
      userId: user.id,
      amount: '444.00',
      transactionId: transactionId || `TXN_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      status: 'completed', // In production, verify with payment gateway
      plan: 'monthly',
    }).returning();

    // Update user subscription
    await db.update(users).set({
      isActive: true,
      subscriptionEnd,
      updatedAt: now,
    }).where(eq(users.id, user.id));

    // Generate new token with updated subscription
    const { generateToken } = await import('@/lib/auth');
    const newToken = generateToken({
      userId: user.id,
      email: user.email,
      phone: user.phone,
      name: user.name,
      isAdmin: user.isAdmin,
      isActive: true,
      subscriptionEnd,
    });

    const { cookies } = await import('next/headers');
    const cookieStore = await cookies();
    cookieStore.set('prawing_token', newToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60,
      path: '/',
    });

    return NextResponse.json({
      message: 'Payment successful. Subscription activated!',
      payment: payment[0],
      subscriptionEnd,
    });
  } catch (error) {
    console.error('Payment error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
