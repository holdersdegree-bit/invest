import { NextResponse } from 'next/server';
import { db } from '@/db';
import { users } from '@/db/schema';
import { hashPassword } from '@/lib/auth';
import { eq } from 'drizzle-orm';

export async function POST(request: Request) {
  try {
    const { name, email, phone, password } = await request.json();

    if (!name || !email || !phone || !password) {
      return NextResponse.json(
        { error: 'All fields are required' },
        { status: 400 }
      );
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: 'Password must be at least 6 characters' },
        { status: 400 }
      );
    }

    // Check if email already exists
    const existingEmail = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (existingEmail.length > 0) {
      return NextResponse.json(
        { error: 'Email already registered' },
        { status: 409 }
      );
    }

    // Check if phone already exists
    const existingPhone = await db.select().from(users).where(eq(users.phone, phone)).limit(1);
    if (existingPhone.length > 0) {
      return NextResponse.json(
        { error: 'Phone number already registered' },
        { status: 409 }
      );
    }

    const passwordHash = await hashPassword(password);

    const newUser = await db.insert(users).values({
      name,
      email,
      phone,
      passwordHash,
      isAdmin: false,
      isActive: false,
    }).returning();

    return NextResponse.json({
      message: 'Registration successful. Please complete payment to activate your subscription.',
      userId: newUser[0].id,
      email: newUser[0].email,
      phone: newUser[0].phone,
    });
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
