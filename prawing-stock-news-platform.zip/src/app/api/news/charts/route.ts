import { NextResponse } from 'next/server';
import { getCurrentUser, hasActiveSubscription } from '@/lib/auth';
import {
  generateCorrelationTrendData,
  generateSectorPerformanceData,
  generateSentimentDistribution,
  generateTopMoversData,
} from '@/lib/newsFetcher';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET() {
  try {
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    if (!hasActiveSubscription(user)) {
      return NextResponse.json(
        { error: 'Subscription required' },
        { status: 403 }
      );
    }

    const correlationTrend = generateCorrelationTrendData(30);
    const sectorPerformance = generateSectorPerformanceData();
    const sentimentDistribution = generateSentimentDistribution();
    const topMovers = generateTopMoversData();

    // Calculate aggregate statistics
    const totalNews = correlationTrend.reduce((sum, d) => sum + d.newsVolume, 0);
    const avgPositive = Math.round(
      correlationTrend.reduce((sum, d) => sum + d.positivePct, 0) / correlationTrend.length
    );
    const avgNegative = Math.round(
      correlationTrend.reduce((sum, d) => sum + d.negativePct, 0) / correlationTrend.length
    );
    const avgNeutral = Math.round(
      correlationTrend.reduce((sum, d) => sum + d.neutralPct, 0) / correlationTrend.length
    );
    const avgImpact = parseFloat(
      (correlationTrend.reduce((sum, d) => sum + d.avgImpact, 0) / correlationTrend.length).toFixed(2)
    );
    const avgMarketChange = parseFloat(
      (correlationTrend.reduce((sum, d) => sum + d.marketChange, 0) / correlationTrend.length).toFixed(2)
    );

    // Calculate overall sentiment correlation with market
    const sentimentMarketCorrelation = parseFloat(
      (
        correlationTrend.reduce((sum, d) => {
          const sentimentIndex = (d.positivePct - d.negativePct) / 100;
          return sum + sentimentIndex * d.marketChange;
        }, 0) / correlationTrend.length
      ).toFixed(4)
    );

    return NextResponse.json({
      correlationTrend,
      sectorPerformance,
      sentimentDistribution,
      topMovers,
      aggregates: {
        totalNews,
        avgPositive,
        avgNegative,
        avgNeutral,
        avgImpact,
        avgMarketChange,
        sentimentMarketCorrelation,
      },
      lastUpdated: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Charts data error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
