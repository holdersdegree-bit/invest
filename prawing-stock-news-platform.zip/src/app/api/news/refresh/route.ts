import { NextResponse } from 'next/server';
import { db } from '@/db';
import { news } from '@/db/schema';
import { getCurrentUser } from '@/lib/auth';
import { generateNews, processNews } from '@/lib/newsFetcher';

export const dynamic = 'force-dynamic';

export async function POST() {
  try {
    const user = await getCurrentUser();

    if (!user || !user.isAdmin) {
      return NextResponse.json(
        { error: 'Unauthorized - Admin access required' },
        { status: 401 }
      );
    }

    // Generate fresh news
    const articles = generateNews(50);
    const processed = processNews(articles);

    const values = processed.map(article => ({
      headline: article.headline,
      summary: article.summary,
      source: article.source,
      sourceUrl: article.sourceUrl,
      category: article.category,
      sentiment: article.sentiment,
      sentimentScore: String(article.sentimentScore),
      impactScore: String(article.impactScore),
      sectorsAffected: article.sectorsAffected,
      stocksAffected: article.stocksAffected,
      historicalCorrelation: article.historicalCorrelation,
      publishedAt: article.publishedAt,
    }));

    await db.insert(news).values(values);

    return NextResponse.json({
      message: `Successfully refreshed with ${processed.length} news articles`,
      count: processed.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('News refresh error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
