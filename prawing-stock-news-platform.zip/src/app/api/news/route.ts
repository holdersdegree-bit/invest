import { NextResponse } from 'next/server';
import { db } from '@/db';
import { news } from '@/db/schema';
import { getCurrentUser, hasActiveSubscription } from '@/lib/auth';
import { generateNews, processNews } from '@/lib/newsFetcher';
import { desc, like, eq, and, gte } from 'drizzle-orm';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET(request: Request) {
  try {
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized - Please login to access news' },
        { status: 401 }
      );
    }

    if (!hasActiveSubscription(user)) {
      return NextResponse.json(
        { error: 'Subscription required - Please complete payment to access news analysis' },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1', 10);
    const limit = parseInt(searchParams.get('limit') || '20', 10);
    const sentiment = searchParams.get('sentiment');
    const source = searchParams.get('source');
    const category = searchParams.get('category');
    const search = searchParams.get('search');

    const offset = (page - 1) * limit;

    // Check if we have recent news (within last 30 minutes)
    const thirtyMinutesAgo = new Date(Date.now() - 30 * 60 * 1000);
    const recentNews = await db
      .select({ count: news.id })
      .from(news)
      .where(gte(news.createdAt, thirtyMinutesAgo));

    let newsCount = 0;
    if (recentNews && recentNews[0]) {
      newsCount = parseInt(String(recentNews[0].count || '0'), 10);
    }

    // If no recent news, generate and store fresh news
    if (newsCount < 5) {
      const articles = generateNews(50);
      const processed = processNews(articles);

      const values = processed.map(article => ({
        headline: article.headline,
        summary: article.summary,
        source: article.source,
        sourceUrl: article.sourceUrl,
        category: article.category,
        sentiment: article.sentiment,
        sentimentScore: String(article.sentimentScore),
        impactScore: String(article.impactScore),
        sectorsAffected: article.sectorsAffected,
        stocksAffected: article.stocksAffected,
        historicalCorrelation: article.historicalCorrelation,
        publishedAt: article.publishedAt,
      }));

      await db.insert(news).values(values);
    }

    // Build query filters
    const conditions = [];
    if (sentiment && sentiment !== 'all') {
      conditions.push(eq(news.sentiment, sentiment));
    }
    if (source && source !== 'all') {
      conditions.push(eq(news.source, source));
    }
    if (category && category !== 'all') {
      conditions.push(eq(news.category, category));
    }
    if (search) {
      conditions.push(like(news.headline, `%${search}%`));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    // Get total count
    const totalResult = await db
      .select({ count: news.id })
      .from(news)
      .where(whereClause);

    const total = totalResult[0]?.count || 0;

    // Get paginated news
    const newsItems = await db
      .select()
      .from(news)
      .where(whereClause)
      .orderBy(desc(news.publishedAt))
      .limit(limit)
      .offset(offset);

    // Get sentiment stats
    const sentimentStats = await db
      .select({
        sentiment: news.sentiment,
        count: news.id,
      })
      .from(news)
      .groupBy(news.sentiment);

    // Get source stats
    const sourceStats = await db
      .select({
        source: news.source,
        count: news.id,
      })
      .from(news)
      .groupBy(news.source)
      .orderBy(desc(news.id))
      .limit(10);

    // Get category stats
    const categoryStats = await db
      .select({
        category: news.category,
        count: news.id,
      })
      .from(news)
      .groupBy(news.category)
      .orderBy(desc(news.id))
      .limit(10);

    return NextResponse.json({
      news: newsItems,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(Number(total) / limit),
      },
      stats: {
        sentiment: sentimentStats,
        sources: sourceStats,
        categories: categoryStats,
      },
      lastUpdated: new Date().toISOString(),
      nextUpdate: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
    });
  } catch (error) {
    console.error('News fetch error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
