'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
  ScatterChart,
  Scatter,
  Cell,
  PieChart,
  Pie,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from 'recharts';

interface NewsItem {
  id: number;
  headline: string;
  summary: string;
  source: string;
  sourceUrl: string;
  category: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  sentimentScore: string;
  impactScore: string;
  sectorsAffected: string[];
  stocksAffected: string[];
  historicalCorrelation: Record<string, any>;
  publishedAt: string;
}

interface ChartData {
  correlationTrend: any[];
  sectorPerformance: any[];
  sentimentDistribution: any[];
  topMovers: any[];
  aggregates: {
    totalNews: number;
    avgPositive: number;
    avgNegative: number;
    avgNeutral: number;
    avgImpact: number;
    avgMarketChange: number;
    sentimentMarketCorrelation: number;
  };
}

const SENTIMENT_COLORS = {
  positive: '#10b981',
  negative: '#ef4444',
  neutral: '#64748b',
};

const SOURCES = [
  'Bloomberg',
  'Money Control',
  'CNBC TV18',
  'Times Now',
  'Mint',
  'NSE India',
  'BSE India',
  'RBI',
  'SEBI',
];

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [chartData, setChartData] = useState<ChartData | null>(null);
  const [selectedNews, setSelectedNews] = useState<NewsItem | null>(null);
  const [filters, setFilters] = useState({
    sentiment: 'all',
    source: 'all',
    category: 'all',
    search: '',
  });
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [lastUpdated, setLastUpdated] = useState('');
  const [countdown, setCountdown] = useState(30 * 60);
  const [activeTab, setActiveTab] = useState<'feed' | 'charts' | 'movers' | 'sectors'>('feed');
  const [stats, setStats] = useState<any>(null);

  // Auth check and load data
  useEffect(() => {
    const init = async () => {
      try {
        // Load user from API (or decode token)
        const userRes = await fetch('/api/auth/me');
        if (userRes.ok) {
          const userData = await userRes.json();
          setUser(userData.user);
        } else {
          // Fallback: try to access dashboard to trigger redirect
          const testRes = await fetch('/api/news');
          if (testRes.status === 401) {
            router.push('/login');
            return;
          }
          if (testRes.status === 403) {
            router.push('/payment');
            return;
          }
        }

        await Promise.all([loadNews(), loadCharts()]);
      } catch (err) {
        console.error('Init error:', err);
      } finally {
        setLoading(false);
      }
    };
    init();
  }, [router]);

  // Countdown timer for next update
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          loadNews();
          loadCharts();
          return 30 * 60;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatCountdown = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const loadNews = useCallback(async () => {
    try {
      const params = new URLSearchParams({
        page: String(page),
        limit: '20',
        ...Object.fromEntries(
          Object.entries(filters).filter(([_, v]) => v && v !== 'all')
        ),
      });
      const res = await fetch(`/api/news?${params}`);
      if (!res.ok) throw new Error('Failed to load news');
      const data = await res.json();
      setNews(data.news);
      setStats(data.stats);
      setTotalPages(data.pagination.totalPages);
      setLastUpdated(data.lastUpdated);
      setCountdown(30 * 60);
    } catch (err) {
      console.error('Load news error:', err);
    }
  }, [page, filters]);

  const loadCharts = useCallback(async () => {
    try {
      const res = await fetch('/api/news/charts');
      if (!res.ok) throw new Error('Failed to load charts');
      const data = await res.json();
      setChartData(data);
    } catch (err) {
      console.error('Load charts error:', err);
    }
  }, []);

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
  };

  const handleRefresh = async () => {
    if (user?.isAdmin) {
      await fetch('/api/news/refresh', { method: 'POST' });
    }
    await Promise.all([loadNews(), loadCharts()]);
  };

  useEffect(() => {
    loadNews();
  }, [page, filters, loadNews]);

  const formatTimeAgo = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-slate-400">Loading PRAWING Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur-xl border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1
              className="text-2xl font-bold bg-gradient-to-r from-emerald-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent tracking-wider cursor-pointer"
              onClick={() => router.push('/dashboard')}
            >
              PRAWING
            </h1>
            {user?.isAdmin && (
              <span className="px-2 py-0.5 bg-amber-500/20 text-amber-400 text-xs font-bold rounded-full border border-amber-500/30">
                ADMIN
              </span>
            )}
          </div>

          <div className="flex items-center gap-4">
            {/* Update Timer */}
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-800/50 rounded-lg border border-slate-700">
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
              <span className="text-xs text-slate-400">
                Next update: <span className="text-emerald-400 font-mono font-bold">{formatCountdown(countdown)}</span>
              </span>
            </div>

            <button
              onClick={handleRefresh}
              className="p-2 bg-slate-800/50 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors"
              title="Refresh data"
            >
              <svg className="w-4 h-4 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            </button>

            <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-800/50 rounded-lg border border-slate-700">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-cyan-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                {user?.name?.charAt(0) || 'U'}
              </div>
              <div className="hidden sm:block">
                <p className="text-sm font-medium text-white">{user?.name || 'User'}</p>
                <p className="text-xs text-slate-400">{user?.email || ''}</p>
              </div>
            </div>

            <button
              onClick={handleLogout}
              className="p-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg border border-red-500/30 transition-colors"
              title="Logout"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
              </svg>
            </button>
          </div>
        </div>

        {/* Stats Bar */}
        {chartData?.aggregates && (
          <div className="max-w-7xl mx-auto px-4 pb-3 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
            {[
              { label: 'News Analyzed', value: chartData.aggregates.totalNews.toLocaleString(), color: 'text-cyan-400' },
              { label: 'Avg Positive', value: `${chartData.aggregates.avgPositive}%`, color: 'text-emerald-400' },
              { label: 'Avg Negative', value: `${chartData.aggregates.avgNegative}%`, color: 'text-red-400' },
              { label: 'Avg Neutral', value: `${chartData.aggregates.avgNeutral}%`, color: 'text-slate-400' },
              { label: 'Avg Impact', value: chartData.aggregates.avgImpact, color: 'text-amber-400' },
              { label: 'Market Corr.', value: (chartData.aggregates.sentimentMarketCorrelation * 100).toFixed(1) + '%', color: 'text-blue-400' },
            ].map(stat => (
              <div key={stat.label} className="bg-slate-800/30 rounded-lg px-3 py-2 border border-slate-800">
                <p className="text-xs text-slate-500">{stat.label}</p>
                <p className={`text-lg font-bold ${stat.color}`}>{stat.value}</p>
              </div>
            ))}
          </div>
        )}

        {/* Tabs */}
        <div className="max-w-7xl mx-auto px-4 pb-3">
          <div className="flex gap-1 bg-slate-800/50 rounded-xl p-1 overflow-x-auto">
            {[
              { id: 'feed', label: '📰 News Feed', icon: '📰' },
              { id: 'charts', label: '📊 Correlation Charts', icon: '📊' },
              { id: 'sectors', label: '🏭 Sector Analysis', icon: '🏭' },
              { id: 'movers', label: '📈 Top Movers', icon: '📈' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 min-w-max py-2 px-4 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-white shadow-lg'
                    : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* News Feed Tab */}
        {activeTab === 'feed' && (
          <div className="grid lg:grid-cols-4 gap-6">
            {/* Filters Sidebar */}
            <div className="lg:col-span-1 space-y-4">
              {/* Search */}
              <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-4">
                <label className="block text-xs font-medium text-slate-400 mb-2">Search Headlines</label>
                <input
                  type="text"
                  value={filters.search}
                  onChange={e => {
                    setFilters(f => ({ ...f, search: e.target.value }));
                    setPage(1);
                  }}
                  placeholder="Search news..."
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Sentiment Filter */}
              <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-4">
                <label className="block text-xs font-medium text-slate-400 mb-3">Sentiment</label>
                <div className="space-y-2">
                  {[
                    { value: 'all', label: 'All', count: stats?.sentiment?.reduce((a: number, b: any) => a + Number(b.count), 0) || 0 },
                    { value: 'positive', label: 'Positive', count: stats?.sentiment?.find((s: any) => s.sentiment === 'positive')?.count || 0, color: 'emerald' },
                    { value: 'negative', label: 'Negative', count: stats?.sentiment?.find((s: any) => s.sentiment === 'negative')?.count || 0, color: 'red' },
                    { value: 'neutral', label: 'Neutral', count: stats?.sentiment?.find((s: any) => s.sentiment === 'neutral')?.count || 0, color: 'slate' },
                  ].map(opt => (
                    <button
                      key={opt.value}
                      onClick={() => {
                        setFilters(f => ({ ...f, sentiment: opt.value }));
                        setPage(1);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-all ${
                        filters.sentiment === opt.value
                          ? 'bg-emerald-500/20 border border-emerald-500/40 text-white'
                          : 'bg-slate-800/50 border border-slate-700 text-slate-300 hover:bg-slate-700/50'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        {opt.color === 'emerald' && <span className="w-2 h-2 bg-emerald-400 rounded-full" />}
                        {opt.color === 'red' && <span className="w-2 h-2 bg-red-400 rounded-full" />}
                        {opt.color === 'slate' && <span className="w-2 h-2 bg-slate-400 rounded-full" />}
                        {opt.label}
                      </span>
                      <span className="text-xs text-slate-400">{opt.count}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Source Filter */}
              <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-4">
                <label className="block text-xs font-medium text-slate-400 mb-3">Source</label>
                <select
                  value={filters.source}
                  onChange={e => {
                    setFilters(f => ({ ...f, source: e.target.value }));
                    setPage(1);
                  }}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">All Sources</option>
                  {SOURCES.map(source => (
                    <option key={source} value={source}>{source}</option>
                  ))}
                </select>
              </div>

              {/* Category Filter */}
              <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-4">
                <label className="block text-xs font-medium text-slate-400 mb-3">Category</label>
                <select
                  value={filters.category}
                  onChange={e => {
                    setFilters(f => ({ ...f, category: e.target.value }));
                    setPage(1);
                  }}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">All Categories</option>
                  {stats?.categories?.map((cat: any) => (
                    <option key={cat.category} value={cat.category}>{cat.category}</option>
                  ))}
                </select>
              </div>

              {/* Sentiment Distribution Mini Chart */}
              {chartData && (
                <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-4">
                  <label className="block text-xs font-medium text-slate-400 mb-3">Sentiment Distribution</label>
                  <ResponsiveContainer width="100%" height={150}>
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'Positive', value: chartData.aggregates.avgPositive, color: SENTIMENT_COLORS.positive },
                          { name: 'Negative', value: chartData.aggregates.avgNegative, color: SENTIMENT_COLORS.negative },
                          { name: 'Neutral', value: chartData.aggregates.avgNeutral, color: SENTIMENT_COLORS.neutral },
                        ]}
                        cx="50%"
                        cy="50%"
                        innerRadius={35}
                        outerRadius={55}
                        dataKey="value"
                      >
                        {[{ color: SENTIMENT_COLORS.positive }, { color: SENTIMENT_COLORS.negative }, { color: SENTIMENT_COLORS.neutral }].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', fontSize: '12px' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex justify-center gap-4 mt-2">
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="w-2 h-2 bg-emerald-400 rounded-full" />
                      <span className="text-slate-400">Pos</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="w-2 h-2 bg-red-400 rounded-full" />
                      <span className="text-slate-400">Neg</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="w-2 h-2 bg-slate-400 rounded-full" />
                      <span className="text-slate-400">Neu</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* News List */}
            <div className="lg:col-span-3 space-y-4">
              {news.length === 0 ? (
                <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-12 text-center">
                  <p className="text-slate-400">No news found matching your filters.</p>
                </div>
              ) : (
                news.map(item => (
                  <div
                    key={item.id}
                    onClick={() => setSelectedNews(item)}
                    className="bg-slate-900/50 rounded-xl border border-slate-800 p-5 hover:border-slate-700 hover:bg-slate-900 transition-all cursor-pointer group"
                  >
                    <div className="flex items-start gap-4">
                      {/* Sentiment Indicator */}
                      <div
                        className="flex-shrink-0 w-14 h-14 rounded-xl flex flex-col items-center justify-center"
                        style={{
                          backgroundColor: `${SENTIMENT_COLORS[item.sentiment]}15`,
                          border: `1px solid ${SENTIMENT_COLORS[item.sentiment]}40`,
                        }}
                      >
                        <span className="text-lg">
                          {item.sentiment === 'positive' ? '📈' : item.sentiment === 'negative' ? '📉' : '➡️'}
                        </span>
                        <span className="text-xs font-bold mt-0.5" style={{ color: SENTIMENT_COLORS[item.sentiment] }}>
                          {Math.abs(Number(item.sentimentScore) * 100).toFixed(0)}%
                        </span>
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-2">
                          <span
                            className="px-2 py-0.5 rounded-full text-xs font-medium"
                            style={{
                              backgroundColor: `${SENTIMENT_COLORS[item.sentiment]}15`,
                              color: SENTIMENT_COLORS[item.sentiment],
                              border: `1px solid ${SENTIMENT_COLORS[item.sentiment]}30`,
                            }}
                          >
                            {item.sentiment.toUpperCase()}
                          </span>
                          <span className="px-2 py-0.5 bg-cyan-500/15 text-cyan-400 rounded-full text-xs font-medium border border-cyan-500/30">
                            {item.source}
                          </span>
                          <span className="px-2 py-0.5 bg-slate-700/50 text-slate-300 rounded-full text-xs">
                            {item.category}
                          </span>
                          <span className="text-xs text-slate-500 ml-auto">
                            {formatTimeAgo(item.publishedAt)}
                          </span>
                        </div>

                        <h3 className="text-base font-semibold text-white group-hover:text-emerald-400 transition-colors mb-2 leading-snug">
                          {item.headline}
                        </h3>

                        <p className="text-sm text-slate-400 line-clamp-2 mb-3">{item.summary}</p>

                        {/* Meta Tags */}
                        <div className="flex flex-wrap items-center gap-3 text-xs">
                          {/* Impact Score */}
                          <div className="flex items-center gap-1.5">
                            <span className="text-slate-500">Impact:</span>
                            <div className="w-20 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                              <div
                                className="h-full bg-gradient-to-r from-amber-400 to-red-500 rounded-full"
                                style={{ width: `${item.impactScore}%` }}
                              />
                            </div>
                            <span className="text-amber-400 font-semibold">{Number(item.impactScore).toFixed(0)}</span>
                          </div>

                          {/* Sectors */}
                          {item.sectorsAffected?.length > 0 && (
                            <div className="flex items-center gap-1 flex-wrap">
                              <span className="text-slate-500">Sectors:</span>
                              {item.sectorsAffected.slice(0, 3).map(sector => (
                                <span key={sector} className="px-1.5 py-0.5 bg-indigo-500/15 text-indigo-400 rounded border border-indigo-500/20">
                                  {sector}
                                </span>
                              ))}
                            </div>
                          )}

                          {/* Stocks */}
                          {item.stocksAffected?.length > 0 && (
                            <div className="flex items-center gap-1 flex-wrap">
                              <span className="text-slate-500">Stocks:</span>
                              {item.stocksAffected.slice(0, 3).map(stock => (
                                <span key={stock} className="px-1.5 py-0.5 bg-blue-500/15 text-blue-400 rounded font-mono text-[10px] border border-blue-500/20">
                                  {stock}
                                </span>
                              ))}
                              {item.stocksAffected.length > 3 && (
                                <span className="text-slate-500">+{item.stocksAffected.length - 3}</span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 pt-4">
                  <button
                    onClick={() => setPage(p => Math.max(1, p - 1))}
                    disabled={page === 1}
                    className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-slate-300 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Previous
                  </button>
                  <span className="px-4 py-2 text-sm text-slate-400">
                    Page {page} of {totalPages}
                  </span>
                  <button
                    onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                    disabled={page === totalPages}
                    className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-slate-300 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Next
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Charts Tab */}
        {activeTab === 'charts' && chartData && (
          <div className="space-y-6">
            {/* Sentiment Trend vs Market Change */}
            <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-bold text-white">Sentiment Trend vs Market Movement (30 Days)</h3>
                  <p className="text-sm text-slate-400 mt-1">Correlation between news sentiment and market price changes</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-500">Correlation Coefficient</p>
                  <p className="text-2xl font-bold text-emerald-400">
                    {(chartData.aggregates.sentimentMarketCorrelation * 100).toFixed(1)}%
                  </p>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={350}>
                <AreaChart data={chartData.correlationTrend}>
                  <defs>
                    <linearGradient id="colorPositive" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorNegative" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickFormatter={v => v.slice(5)} />
                  <YAxis yAxisId="left" stroke="#64748b" fontSize={11} />
                  <YAxis yAxisId="right" orientation="right" stroke="#64748b" fontSize={11} tickFormatter={v => `${v}%`} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', fontSize: '12px' }}
                  />
                  <Legend />
                  <Area yAxisId="left" type="monotone" dataKey="positivePct" name="Positive %" stroke="#10b981" fillOpacity={1} fill="url(#colorPositive)" />
                  <Area yAxisId="left" type="monotone" dataKey="negativePct" name="Negative %" stroke="#ef4444" fillOpacity={1} fill="url(#colorNegative)" />
                  <Line yAxisId="right" type="monotone" dataKey="marketChange" name="Market Change %" stroke="#06b6d4" strokeWidth={2} dot={{ r: 3 }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* News Volume & Impact */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-6">
                <h3 className="text-lg font-bold text-white mb-4">News Volume & Average Impact</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData.correlationTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="date" stroke="#64748b" fontSize={10} tickFormatter={v => v.slice(8)} />
                    <YAxis yAxisId="left" stroke="#64748b" fontSize={10} />
                    <YAxis yAxisId="right" orientation="right" stroke="#64748b" fontSize={10} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', fontSize: '12px' }}
                    />
                    <Legend />
                    <Bar yAxisId="left" dataKey="newsVolume" name="News Volume" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                    <Line yAxisId="right" type="monotone" dataKey="avgImpact" name="Avg Impact Score" stroke="#f59e0b" strokeWidth={2} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Sentiment Score Distribution */}
              <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-6">
                <h3 className="text-lg font-bold text-white mb-4">Sentiment Score Distribution</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData.sentimentDistribution}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="range" stroke="#64748b" fontSize={9} angle={-30} textAnchor="end" height={60} />
                    <YAxis stroke="#64748b" fontSize={10} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', fontSize: '12px' }}
                    />
                    <Bar dataKey="count" name="News Count" radius={[4, 4, 0, 0]}>
                      {chartData.sentimentDistribution.map((entry, index) => {
                        const mid = (parseFloat(entry.range.split(' ')[0]) + parseFloat(entry.range.split(' ')[2])) / 2;
                        const color = mid > 0.1 ? '#10b981' : mid < -0.1 ? '#ef4444' : '#64748b';
                        return <Cell key={`cell-${index}`} fill={color} />;
                      })}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Sentiment vs Price Change Scatter */}
            <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-6">
              <h3 className="text-lg font-bold text-white mb-4">News Sentiment Score vs Market Change Correlation</h3>
              <ResponsiveContainer width="100%" height={350}>
                <ScatterChart>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis
                    type="number"
                    dataKey="sentimentIndex"
                    name="Sentiment Index"
                    stroke="#64748b"
                    fontSize={11}
                    tickFormatter={v => v.toFixed(1)}
                    label={{ value: 'Sentiment Index (Pos% - Neg%)', position: 'bottom', fill: '#64748b', fontSize: 12 }}
                  />
                  <YAxis
                    type="number"
                    dataKey="marketChange"
                    name="Market Change"
                    stroke="#64748b"
                    fontSize={11}
                    tickFormatter={v => `${v}%`}
                    label={{ value: 'Market Change %', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 12 }}
                  />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', fontSize: '12px' }}
                    cursor={{ strokeDasharray: '3 3' }}
                  />
                  <Scatter
                    data={chartData.correlationTrend.map(d => ({
                      ...d,
                      sentimentIndex: (d.positivePct - d.negativePct) / 100,
                    }))}
                  >
                    {chartData.correlationTrend.map((d, i) => {
                      const si = (d.positivePct - d.negativePct) / 100;
                      return (
                        <Cell
                          key={i}
                          fill={si > 0.1 ? '#10b981' : si < -0.1 ? '#ef4444' : '#64748b'}
                          fillOpacity={0.7}
                        />
                      );
                    })}
                  </Scatter>
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Sectors Tab */}
        {activeTab === 'sectors' && chartData && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Sector Radar */}
              <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-6">
                <h3 className="text-lg font-bold text-white mb-4">Sector Sentiment Radar</h3>
                <ResponsiveContainer width="100%" height={350}>
                  <RadarChart data={chartData.sectorPerformance.slice(0, 8)}>
                    <PolarGrid stroke="#334155" />
                    <PolarAngleAxis dataKey="sector" stroke="#94a3b8" fontSize={10} />
                    <PolarRadiusAxis stroke="#475569" fontSize={9} />
                    <Radar name="Positive Sentiment %" dataKey="positiveSentiment" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                    <Radar name="Correlation" dataKey={d => d.correlation * 100} stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.2} />
                    <Legend />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', fontSize: '12px' }}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>

              {/* Sector Price Change */}
              <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-6">
                <h3 className="text-lg font-bold text-white mb-4">Sector Price Change vs News Volume</h3>
                <ResponsiveContainer width="100%" height={350}>
                  <BarChart data={chartData.sectorPerformance} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis type="number" stroke="#64748b" fontSize={10} tickFormatter={v => `${v}%`} />
                    <YAxis dataKey="sector" type="category" stroke="#64748b" fontSize={10} width={90} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', fontSize: '12px' }}
                    />
                    <Legend />
                    <Bar dataKey="priceChange" name="Price Change %" radius={[0, 4, 4, 0]}>
                      {chartData.sectorPerformance.map((entry, index) => (
                        <Cell key={index} fill={entry.priceChange >= 0 ? '#10b981' : '#ef4444'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Sector Detail Table */}
            <div className="bg-slate-900/50 rounded-xl border border-slate-800 overflow-hidden">
              <div className="p-6 border-b border-slate-800">
                <h3 className="text-lg font-bold text-white">Sector Performance & News Correlation</h3>
                <p className="text-sm text-slate-400 mt-1">Detailed breakdown of news impact across sectors</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-800/50">
                    <tr>
                      <th className="text-left px-6 py-3 font-semibold text-slate-300">Sector</th>
                      <th className="text-right px-6 py-3 font-semibold text-slate-300">News Count</th>
                      <th className="text-right px-6 py-3 font-semibold text-slate-300">Positive Sentiment</th>
                      <th className="text-right px-6 py-3 font-semibold text-slate-300">Avg Impact</th>
                      <th className="text-right px-6 py-3 font-semibold text-slate-300">Price Change</th>
                      <th className="text-right px-6 py-3 font-semibold text-slate-300">Correlation</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {chartData.sectorPerformance.map((sector, i) => (
                      <tr key={i} className="hover:bg-slate-800/30 transition-colors">
                        <td className="px-6 py-4 font-medium text-white">{sector.sector}</td>
                        <td className="px-6 py-4 text-right text-slate-300">{sector.newsCount}</td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <div className="w-20 h-2 bg-slate-700 rounded-full overflow-hidden">
                              <div className="h-full bg-emerald-500" style={{ width: `${sector.positiveSentiment}%` }} />
                            </div>
                            <span className="text-emerald-400 font-semibold w-12 text-right">{sector.positiveSentiment}%</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-right text-amber-400 font-semibold">{sector.avgImpact}</td>
                        <td className={`px-6 py-4 text-right font-bold ${sector.priceChange >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {sector.priceChange >= 0 ? '+' : ''}{sector.priceChange}%
                        </td>
                        <td className="px-6 py-4 text-right">
                          <span className="px-2 py-1 bg-cyan-500/15 text-cyan-400 rounded text-xs font-mono border border-cyan-500/30">
                            {(sector.correlation * 100).toFixed(0)}%
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Top Movers Tab */}
        {activeTab === 'movers' && chartData && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Top Gainers */}
              <div className="bg-slate-900/50 rounded-xl border border-slate-800 overflow-hidden">
                <div className="p-6 border-b border-slate-800 bg-emerald-500/5">
                  <h3 className="text-lg font-bold text-emerald-400 flex items-center gap-2">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                    Top Gainers
                  </h3>
                  <p className="text-sm text-slate-400 mt-1">Stocks with highest positive price movement</p>
                </div>
                <div className="divide-y divide-slate-800">
                  {chartData.topMovers
                    .filter(m => m.priceChange > 0)
                    .slice(0, 8)
                    .map((mover, i) => (
                      <div key={i} className="p-4 hover:bg-slate-800/30 transition-colors">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-emerald-500/15 rounded-lg flex items-center justify-center text-emerald-400 font-bold">
                              {i + 1}
                            </div>
                            <div>
                              <p className="font-semibold text-white">{mover.name}</p>
                              <p className="text-xs text-slate-400">
                                <span className="font-mono text-blue-400">{mover.symbol}</span> • {mover.sector}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold text-emerald-400">+{mover.priceChange}%</p>
                            <p className="text-xs text-slate-400">{mover.newsCount} news articles</p>
                          </div>
                        </div>
                        <div className="mt-3 flex items-center gap-3 text-xs">
                          <div className="flex items-center gap-1.5">
                            <span className="text-slate-500">Sentiment:</span>
                            <span className={mover.sentimentScore >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                              {(mover.sentimentScore * 100).toFixed(0)}%
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-slate-500">Correlation:</span>
                            <span className="text-cyan-400">{(mover.correlation * 100).toFixed(0)}%</span>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              {/* Top Losers */}
              <div className="bg-slate-900/50 rounded-xl border border-slate-800 overflow-hidden">
                <div className="p-6 border-b border-slate-800 bg-red-500/5">
                  <h3 className="text-lg font-bold text-red-400 flex items-center gap-2">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6" />
                    </svg>
                    Top Losers
                  </h3>
                  <p className="text-sm text-slate-400 mt-1">Stocks with highest negative price movement</p>
                </div>
                <div className="divide-y divide-slate-800">
                  {chartData.topMovers
                    .filter(m => m.priceChange < 0)
                    .slice(0, 8)
                    .map((mover, i) => (
                      <div key={i} className="p-4 hover:bg-slate-800/30 transition-colors">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-red-500/15 rounded-lg flex items-center justify-center text-red-400 font-bold">
                              {i + 1}
                            </div>
                            <div>
                              <p className="font-semibold text-white">{mover.name}</p>
                              <p className="text-xs text-slate-400">
                                <span className="font-mono text-blue-400">{mover.symbol}</span> • {mover.sector}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold text-red-400">{mover.priceChange}%</p>
                            <p className="text-xs text-slate-400">{mover.newsCount} news articles</p>
                          </div>
                        </div>
                        <div className="mt-3 flex items-center gap-3 text-xs">
                          <div className="flex items-center gap-1.5">
                            <span className="text-slate-500">Sentiment:</span>
                            <span className={mover.sentimentScore >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                              {(mover.sentimentScore * 100).toFixed(0)}%
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-slate-500">Correlation:</span>
                            <span className="text-cyan-400">{(mover.correlation * 100).toFixed(0)}%</span>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </div>

            {/* Movers Scatter Plot */}
            <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-6">
              <h3 className="text-lg font-bold text-white mb-4">Sentiment Score vs Price Change Correlation (Top Movers)</h3>
              <ResponsiveContainer width="100%" height={400}>
                <ScatterChart>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis
                    type="number"
                    dataKey="sentimentScore"
                    name="Sentiment Score"
                    stroke="#64748b"
                    fontSize={11}
                    domain={[-1, 1]}
                    tickFormatter={v => (v * 100).toFixed(0) + '%'}
                    label={{ value: 'News Sentiment Score →', position: 'bottom', fill: '#64748b', fontSize: 12 }}
                  />
                  <YAxis
                    type="number"
                    dataKey="priceChange"
                    name="Price Change"
                    stroke="#64748b"
                    fontSize={11}
                    tickFormatter={v => `${v}%`}
                    label={{ value: 'Price Change % →', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 12 }}
                  />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', fontSize: '12px' }}
                    cursor={{ strokeDasharray: '3 3' }}
                    formatter={(value: any, name: any) => {
                      if (name === 'Sentiment Score') return [(value * 100).toFixed(0) + '%', name];
                      if (name === 'Price Change') return [value + '%', name];
                      if (name === 'Correlation') return [(value * 100).toFixed(0) + '%', name];
                      return [value, name];
                    }}
                  />
                  <Scatter data={chartData.topMovers}>
                    {chartData.topMovers.map((mover, i) => (
                      <Cell
                        key={i}
                        fill={mover.priceChange >= 0 ? '#10b981' : '#ef4444'}
                        fillOpacity={0.6 + mover.correlation * 0.4}
                        stroke={mover.priceChange >= 0 ? '#10b981' : '#ef4444'}
                        strokeWidth={1}
                      />
                    ))}
                  </Scatter>
                </ScatterChart>
              </ResponsiveContainer>
              <p className="text-xs text-slate-500 mt-3 text-center">
                Bubble opacity indicates correlation strength. Size is relative to news volume.
              </p>
            </div>
          </div>
        )}
      </main>

      {/* News Detail Modal */}
      {selectedNews && (
        <div
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSelectedNews(null)}
        >
          <div
            className="bg-slate-900 rounded-2xl border border-slate-800 max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
            onClick={e => e.stopPropagation()}
          >
            {/* Header */}
            <div
              className="p-6 border-b border-slate-800 sticky top-0 bg-slate-900 z-10"
              style={{
                borderTop: `4px solid ${SENTIMENT_COLORS[selectedNews.sentiment]}`,
              }}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-3">
                    <span
                      className="px-3 py-1 rounded-full text-xs font-bold uppercase"
                      style={{
                        backgroundColor: `${SENTIMENT_COLORS[selectedNews.sentiment]}20`,
                        color: SENTIMENT_COLORS[selectedNews.sentiment],
                        border: `1px solid ${SENTIMENT_COLORS[selectedNews.sentiment]}40`,
                      }}
                    >
                      {selectedNews.sentiment} • {(Math.abs(Number(selectedNews.sentimentScore)) * 100).toFixed(0)}% Confidence
                    </span>
                    <span className="px-3 py-1 bg-cyan-500/15 text-cyan-400 rounded-full text-xs font-medium border border-cyan-500/30">
                      {selectedNews.source}
                    </span>
                    <span className="px-3 py-1 bg-slate-700/50 text-slate-300 rounded-full text-xs">
                      {selectedNews.category}
                    </span>
                  </div>
                  <h2 className="text-xl font-bold text-white leading-snug">{selectedNews.headline}</h2>
                  <p className="text-sm text-slate-400 mt-2">
                    Published {formatTimeAgo(selectedNews.publishedAt)} •{' '}
                    <a
                      href={selectedNews.sourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-emerald-400 hover:underline"
                    >
                      View Source →
                    </a>
                  </p>
                </div>
                <button
                  onClick={() => setSelectedNews(null)}
                  className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex-shrink-0"
                >
                  <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>

            {/* Body */}
            <div className="p-6 space-y-6">
              {/* Summary */}
              <div>
                <h4 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-2">Summary</h4>
                <p className="text-slate-200 leading-relaxed">{selectedNews.summary}</p>
              </div>

              {/* Impact Score */}
              <div className="bg-slate-800/50 rounded-xl p-5 border border-slate-700">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-sm font-semibold text-slate-300">Market Impact Score</h4>
                  <span className="text-3xl font-bold text-amber-400">{Number(selectedNews.impactScore).toFixed(1)}</span>
                </div>
                <div className="w-full h-3 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-400 via-amber-400 to-red-500 rounded-full transition-all"
                    style={{ width: `${selectedNews.impactScore}%` }}
                  />
                </div>
                <div className="flex justify-between mt-2 text-xs text-slate-500">
                  <span>Low Impact</span>
                  <span>Medium</span>
                  <span>High Impact</span>
                </div>
              </div>

              {/* Historical Impact */}
              {selectedNews.historicalCorrelation && (
                <div>
                  <h4 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">
                    Historical Price Impact (Similar News Events)
                  </h4>
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { label: '1 Hour', value: selectedNews.historicalCorrelation.oneHourImpact, key: '1h' },
                      { label: '24 Hours', value: selectedNews.historicalCorrelation.twentyFourHourImpact, key: '24h' },
                      { label: '7 Days', value: selectedNews.historicalCorrelation.sevenDayImpact, key: '7d' },
                    ].map(item => (
                      <div key={item.key} className="bg-slate-800/50 rounded-xl p-4 border border-slate-700 text-center">
                        <p className="text-xs text-slate-400 mb-1">{item.label}</p>
                        <p className={`text-2xl font-bold ${Number(item.value) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {Number(item.value) >= 0 ? '+' : ''}{Number(item.value).toFixed(2)}%
                        </p>
                      </div>
                    ))}
                  </div>

                  {/* Impact Mini Chart */}
                  <div className="mt-4 bg-slate-800/30 rounded-xl p-4 border border-slate-700/50">
                    <ResponsiveContainer width="100%" height={120}>
                      <LineChart
                        data={[
                          { time: '1h', impact: Number(selectedNews.historicalCorrelation.oneHourImpact) },
                          { time: '6h', impact: Number(selectedNews.historicalCorrelation.oneHourImpact) * 1.5 },
                          { time: '24h', impact: Number(selectedNews.historicalCorrelation.twentyFourHourImpact) },
                          { time: '3d', impact: Number(selectedNews.historicalCorrelation.twentyFourHourImpact) * 1.2 },
                          { time: '7d', impact: Number(selectedNews.historicalCorrelation.sevenDayImpact) },
                        ]}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                        <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                        <YAxis stroke="#64748b" fontSize={10} tickFormatter={v => `${v}%`} />
                        <Tooltip
                          contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', fontSize: '12px' }}
                        />
                        <Line
                          type="monotone"
                          dataKey="impact"
                          stroke={Number(selectedNews.historicalCorrelation.sevenDayImpact) >= 0 ? '#10b981' : '#ef4444'}
                          strokeWidth={2}
                          dot={{ r: 4 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div className="bg-slate-800/30 rounded-lg p-3 border border-slate-700/50">
                      <p className="text-xs text-slate-400">Prediction Accuracy</p>
                      <p className="text-xl font-bold text-cyan-400">{selectedNews.historicalCorrelation.historicalAccuracy}%</p>
                    </div>
                    <div className="bg-slate-800/30 rounded-lg p-3 border border-slate-700/50">
                      <p className="text-xs text-slate-400">Historical Events Analyzed</p>
                      <p className="text-xl font-bold text-indigo-400">{selectedNews.historicalCorrelation.sampleSize}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Sectors Affected */}
              {selectedNews.sectorsAffected?.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-3">Sectors Affected</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedNews.sectorsAffected.map(sector => {
                      const sectorImpact = selectedNews.historicalCorrelation?.sectorImpacts?.[sector] || 0;
                      return (
                        <div
                          key={sector}
                          className="px-4 py-2 bg-indigo-500/10 border border-indigo-500/30 rounded-lg flex items-center gap-3"
                        >
                          <span className="text-indigo-300 font-medium">{sector}</span>
                          <span
                            className={`text-xs font-bold px-2 py-0.5 rounded ${
                              sectorImpact >= 0
                                ? 'bg-emerald-500/20 text-emerald-400'
                                : 'bg-red-500/20 text-red-400'
                            }`}
                          >
                            {sectorImpact >= 0 ? '+' : ''}{Number(sectorImpact).toFixed(2)}%
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Stocks Affected */}
              {selectedNews.stocksAffected?.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-3">Stocks to Watch</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                    {selectedNews.stocksAffected.map(stock => (
                      <div
                        key={stock}
                        className="px-3 py-2 bg-blue-500/10 border border-blue-500/30 rounded-lg text-center"
                      >
                        <p className="font-mono font-bold text-blue-300">{stock}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Additional Stats */}
              {selectedNews.historicalCorrelation && (
                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-500/15 rounded-lg flex items-center justify-center">
                      <span className="text-lg">📊</span>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400">Volatility Impact</p>
                      <p className="font-bold text-purple-400">+{selectedNews.historicalCorrelation.volatilityImpact}%</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-orange-500/15 rounded-lg flex items-center justify-center">
                      <span className="text-lg">📦</span>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400">Volume Surge</p>
                      <p className="font-bold text-orange-400">+{selectedNews.historicalCorrelation.volumeImpact}%</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-800 mt-12 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-2xl font-bold bg-gradient-to-r from-emerald-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent tracking-wider mb-2">
            PRAWING
          </p>
          <p className="text-sm text-slate-500 mb-4">
            Indian Stock Market News Impact & Sentiment Analysis Platform
          </p>
          <div className="flex flex-wrap justify-center gap-4 text-xs text-slate-500">
            <span>Sources: Bloomberg • Money Control • CNBC TV18 • Times Now • Mint • NSE • BSE • RBI • SEBI</span>
          </div>
          <p className="text-xs text-slate-600 mt-4">
            © {new Date().getFullYear()} PRAWING Analytics. All data is for informational purposes only.
          </p>
        </div>
      </footer>
    </div>
  );
}
