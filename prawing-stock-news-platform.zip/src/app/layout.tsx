import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import './globals.css';

export const metadata: Metadata = {
  title: 'PRAWING - Indian Stock Market News Impact Analysis',
  description:
    'Real-time news analysis with sentiment scoring and historical price impact correlation for Indian stock market. Sources include Bloomberg, Money Control, CNBC TV18, Mint, RBI, SEBI and more.',
  keywords: [
    'Indian stock market',
    'news analysis',
    'sentiment analysis',
    'stock market news',
    'Bloomberg India',
    'Money Control',
    'CNBC TV18',
    'RBI policy',
    'SEBI news',
    'market impact',
    'price correlation',
    'PRAWING',
  ],
  authors: [{ name: 'PRAWING Analytics' }],
  viewport: 'width=device-width, initial-scale=1',
  openGraph: {
    title: 'PRAWING - Indian Stock Market News Impact Analysis',
    description:
      'Real-time news analysis with sentiment scoring and historical price impact correlation for Indian stock market.',
    type: 'website',
    siteName: 'PRAWING',
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-950 text-slate-100 antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
