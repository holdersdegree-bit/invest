import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import { verifyToken, hasActiveSubscription } from '@/lib/auth';

export default async function Home() {
  const cookieStore = await cookies();
  const token = cookieStore.get('prawing_token')?.value;

  if (!token) {
    redirect('/login');
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    redirect('/login');
  }

  const user = {
    isActive: decoded.isActive as boolean,
    subscriptionEnd: decoded.subscriptionEnd ? new Date(decoded.subscriptionEnd as string) : null,
    isAdmin: decoded.isAdmin as boolean,
  };

  if (!hasActiveSubscription(user)) {
    redirect('/payment');
  }

  redirect('/dashboard');
}
