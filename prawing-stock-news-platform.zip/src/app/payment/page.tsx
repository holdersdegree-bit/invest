'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function PaymentPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');
  const [user, setUser] = useState<{ name: string; email: string; phone: string } | null>(null);
  const [selectedMethod, setSelectedMethod] = useState('upi');
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  useEffect(() => {
    // Get user info from token (simplified - in production use API)
    const getToken = async () => {
      try {
        const res = await fetch('/api/auth/me');
        if (res.ok) {
          const data = await res.json();
          setUser(data.user);
        }
      } catch {
        // Token might be valid but /me endpoint not yet created
      }
    };
    getToken();
  }, []);

  const handlePayment = async () => {
    setProcessing(true);
    setError('');

    try {
      // Simulate payment processing delay
      await new Promise(resolve => setTimeout(resolve, 2000));

      const res = await fetch('/api/auth/payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          paymentMethod: selectedMethod,
          transactionId: `PRAWING_${Date.now()}_${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Payment failed');
      }

      setPaymentSuccess(true);
      setTimeout(() => {
        router.push('/dashboard');
      }, 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Payment failed. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  const paymentMethods = [
    { id: 'upi', name: 'UPI', icon: '📱', desc: 'Google Pay, PhonePe, Paytm' },
    { id: 'card', name: 'Credit / Debit Card', icon: '💳', desc: 'Visa, Mastercard, RuPay' },
    { id: 'netbanking', name: 'Net Banking', icon: '🏦', desc: 'All major banks' },
    { id: 'wallet', name: 'Wallet', icon: '👛', desc: 'Paytm, Amazon Pay, Mobikwik' },
  ];

  if (paymentSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 flex items-center justify-center p-4">
        <div className="bg-slate-900/80 backdrop-blur-xl rounded-2xl shadow-2xl border border-slate-800 p-10 text-center max-w-md w-full">
          <div className="w-24 h-24 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
            <svg className="w-12 h-12 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-3xl font-bold text-white mb-3">Payment Successful!</h2>
          <p className="text-slate-400 mb-6">
            Your subscription has been activated. Redirecting to dashboard...
          </p>
          <div className="inline-flex items-center gap-2 text-emerald-400">
            <div className="w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
            Activating your account
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1
            className="text-4xl font-bold bg-gradient-to-r from-emerald-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent tracking-wider cursor-pointer"
            onClick={() => router.push('/login')}
          >
            PRAWING
          </h1>
          <p className="text-slate-400 mt-2">Activate your subscription to unlock all features</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Order Summary */}
          <div className="bg-slate-900/80 backdrop-blur-xl rounded-2xl shadow-2xl border border-slate-800 p-8">
            <h2 className="text-xl font-bold text-white mb-6">Order Summary</h2>

            {/* Plan Card */}
            <div className="bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 border border-emerald-500/30 rounded-xl p-5 mb-6">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-lg font-semibold text-white">PRAWING Premium</h3>
                  <p className="text-sm text-slate-400">Monthly Subscription</p>
                </div>
                <span className="px-3 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-semibold rounded-full">
                  POPULAR
                </span>
              </div>
              <div className="text-4xl font-bold text-white mb-2">
                ₹444<span className="text-lg font-normal text-slate-400">/month</span>
              </div>
              <p className="text-xs text-emerald-400">Billed monthly. Cancel anytime.</p>
            </div>

            {/* Features */}
            <div className="space-y-3 mb-6">
              {[
                'Real-time news from 9+ sources',
                'Sentiment analysis (Positive/Negative/Neutral)',
                'Historical price impact correlation',
                'Interactive charts & trends',
                'Sector-wise performance analysis',
                'Top movers with news correlation',
                'News updates every 30 minutes',
                'Premium support',
              ].map(feature => (
                <div key={feature} className="flex items-center gap-3 text-sm text-slate-300">
                  <svg className="w-5 h-5 text-emerald-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  {feature}
                </div>
              ))}
            </div>

            {/* Billing */}
            <div className="border-t border-slate-800 pt-5 space-y-2">
              <div className="flex justify-between text-slate-400 text-sm">
                <span>Subtotal</span>
                <span>₹444.00</span>
              </div>
              <div className="flex justify-between text-slate-400 text-sm">
                <span>GST (18%)</span>
                <span>₹79.92</span>
              </div>
              <div className="flex justify-between text-white font-bold text-lg pt-2 border-t border-slate-800">
                <span>Total</span>
                <span>₹523.92</span>
              </div>
            </div>
          </div>

          {/* Payment Methods */}
          <div className="bg-slate-900/80 backdrop-blur-xl rounded-2xl shadow-2xl border border-slate-800 p-8">
            <h2 className="text-xl font-bold text-white mb-6">Payment Method</h2>

            {error && (
              <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm">
                {error}
              </div>
            )}

            {/* Methods */}
            <div className="space-y-3 mb-6">
              {paymentMethods.map(method => (
                <button
                  key={method.id}
                  onClick={() => setSelectedMethod(method.id)}
                  className={`w-full p-4 rounded-xl border-2 transition-all flex items-center gap-4 text-left ${
                    selectedMethod === method.id
                      ? 'border-emerald-500 bg-emerald-500/10'
                      : 'border-slate-700 bg-slate-800/50 hover:border-slate-600'
                  }`}
                >
                  <span className="text-2xl">{method.icon}</span>
                  <div className="flex-1">
                    <p className="font-medium text-white">{method.name}</p>
                    <p className="text-xs text-slate-400">{method.desc}</p>
                  </div>
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      selectedMethod === method.id ? 'border-emerald-500' : 'border-slate-500'
                    }`}
                  >
                    {selectedMethod === method.id && (
                      <div className="w-3 h-3 bg-emerald-500 rounded-full" />
                    )}
                  </div>
                </button>
              ))}
            </div>

            {/* Demo Payment Info */}
            <div className="mb-6 p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl">
              <p className="text-xs text-amber-400">
                <span className="font-semibold">Demo Mode:</span> This is a simulated payment. No actual
                charges will be made. Click "Pay Now" to activate your subscription.
              </p>
            </div>

            {/* UPI Demo Input */}
            {selectedMethod === 'upi' && (
              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-300 mb-2">UPI ID</label>
                <input
                  type="text"
                  placeholder="yourname@upi"
                  defaultValue="demo@okicici"
                  className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            )}

            {/* Pay Button */}
            <button
              onClick={handlePayment}
              disabled={processing}
              className="w-full py-4 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold rounded-xl shadow-lg shadow-emerald-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed text-lg"
            >
              {processing ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Processing Payment...
                </span>
              ) : (
                <span className="flex items-center justify-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                  Pay ₹523.92 Securely
                </span>
              )}
            </button>

            <p className="text-xs text-slate-500 text-center mt-4 flex items-center justify-center gap-1">
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
              Secured with 256-bit SSL encryption
            </p>

            <button
              onClick={() => router.push('/login')}
              className="w-full mt-4 py-2 text-slate-400 hover:text-white text-sm transition-colors"
            >
              ← Back to Login
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
