import { pgTable, serial, text, varchar, integer, timestamp, boolean, numeric, jsonb } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 100 }),
  email: varchar('email', { length: 100 }).unique(),
  phone: varchar('phone', { length: 20 }).unique(),
  passwordHash: varchar('password_hash', { length: 255 }),
  isAdmin: boolean('is_admin').default(false),
  isActive: boolean('is_active').default(false),
  subscriptionEnd: timestamp('subscription_end'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const otpCodes = pgTable('otp_codes', {
  id: serial('id').primaryKey(),
  phone: varchar('phone', { length: 20 }).notNull(),
  code: varchar('code', { length: 6 }).notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  used: boolean('used').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

export const payments = pgTable('payments', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  amount: numeric('amount', { precision: 10, scale: 2 }).notNull(),
  transactionId: varchar('transaction_id', { length: 100 }),
  status: varchar('status', { length: 20 }).default('pending'),
  plan: varchar('plan', { length: 50 }).default('monthly'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const news = pgTable('news', {
  id: serial('id').primaryKey(),
  headline: text('headline').notNull(),
  summary: text('summary'),
  source: varchar('source', { length: 50 }).notNull(),
  sourceUrl: text('source_url'),
  category: varchar('category', { length: 50 }),
  sentiment: varchar('sentiment', { length: 20 }), // positive, negative, neutral
  sentimentScore: numeric('sentiment_score', { precision: 5, scale: 2 }),
  impactScore: numeric('impact_score', { precision: 5, scale: 2 }),
  sectorsAffected: jsonb('sectors_affected').default([]),
  stocksAffected: jsonb('stocks_affected').default([]),
  historicalCorrelation: jsonb('historical_correlation').default({}),
  publishedAt: timestamp('published_at').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

export const priceHistory = pgTable('price_history', {
  id: serial('id').primaryKey(),
  symbol: varchar('symbol', { length: 20 }).notNull(),
  name: varchar('name', { length: 100 }),
  sector: varchar('sector', { length: 50 }),
  price: numeric('price', { precision: 15, scale: 2 }),
  changePercent: numeric('change_percent', { precision: 10, scale: 4 }),
  volume: numeric('volume', { precision: 20, scale: 0 }),
  recordedAt: timestamp('recorded_at').defaultNow(),
});

export const newsImpactLogs = pgTable('news_impact_logs', {
  id: serial('id').primaryKey(),
  newsId: integer('news_id').references(() => news.id),
  symbol: varchar('symbol', { length: 20 }),
  priceBefore: numeric('price_before', { precision: 15, scale: 2 }),
  priceAfter1h: numeric('price_after_1h', { precision: 15, scale: 2 }),
  priceAfter24h: numeric('price_after_24h', { precision: 15, scale: 2 }),
  impact1h: numeric('impact_1h', { precision: 10, scale: 4 }),
  impact24h: numeric('impact_24h', { precision: 10, scale: 4 }),
  createdAt: timestamp('created_at').defaultNow(),
});
