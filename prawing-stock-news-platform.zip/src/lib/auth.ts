import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { cookies } from 'next/headers';

const JWT_SECRET = process.env.JWT_SECRET || 'prawing-secret-key-change-in-production-2024';
const ADMIN_PHONE = '8341934699';

export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function generateToken(payload: Record<string, unknown>): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '30d' });
}

export function verifyToken(token: string): Record<string, unknown> | null {
  try {
    return jwt.verify(token, JWT_SECRET) as Record<string, unknown>;
  } catch {
    return null;
  }
}

export function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

export function isAdminPhone(phone: string): boolean {
  return phone.replace(/\D/g, '') === ADMIN_PHONE;
}

export async function getCurrentUser(): Promise<{
  id: number;
  email: string;
  phone: string;
  name: string;
  isAdmin: boolean;
  isActive: boolean;
  subscriptionEnd: Date | null;
} | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get('prawing_token')?.value;

  if (!token) return null;

  const decoded = verifyToken(token);
  if (!decoded) return null;

  return {
    id: decoded.userId as number,
    email: decoded.email as string,
    phone: decoded.phone as string,
    name: decoded.name as string,
    isAdmin: decoded.isAdmin as boolean,
    isActive: decoded.isActive as boolean,
    subscriptionEnd: decoded.subscriptionEnd ? new Date(decoded.subscriptionEnd as string) : null,
  };
}

export function setAuthCookie(token: string): void {
  // This is handled in API routes with cookies() directly
  void token;
}

export function clearAuthCookie(): void {
  // This is handled in API routes with cookies() directly
}

export function hasActiveSubscription(user: {
  isActive: boolean;
  subscriptionEnd: Date | null;
  isAdmin: boolean;
}): boolean {
  if (user.isAdmin) return true;
  if (!user.isActive) return false;
  if (!user.subscriptionEnd) return false;
  return new Date(user.subscriptionEnd) > new Date();
}

export const SUBSCRIPTION_PRICE = 444;
export const SUBSCRIPTION_DURATION_DAYS = 30;
