// News fetcher for Indian stock market sources
// Simulates fetching from Bloomberg, Money Control, CNBC TV18, Times Now, Mint, NSE India, BSE India, RBI, SEBI

import { analyzeSentiment, calculateImpactScore, identifySectors, identifyStocks } from './sentiment';

export interface NewsArticle {
  headline: string;
  summary: string;
  source: string;
  sourceUrl: string;
  category: string;
  publishedAt: Date;
}

const newsSources = [
  { name: 'Bloomberg', baseUrl: 'https://www.bloomberg.com/india', categories: ['Markets', 'Economy', 'Policy', 'Corporate'] },
  { name: 'Money Control', baseUrl: 'https://www.moneycontrol.com', categories: ['Markets', 'Earnings', 'Sector News', 'IPO', 'Commodities'] },
  { name: 'CNBC TV18', baseUrl: 'https://www.cnbctv18.com', categories: ['Markets', 'Business', 'Economy', 'Corporate', 'Policy'] },
  { name: 'Times Now', baseUrl: 'https://www.timesnownews.com/business-economy', categories: ['Markets', 'Economy', 'Business', 'Policy'] },
  { name: 'Mint', baseUrl: 'https://www.livemint.com', categories: ['Markets', 'Companies', 'Economy', 'Politics', 'Money'] },
  { name: 'NSE India', baseUrl: 'https://www.nseindia.com', categories: ['Corporate Action', 'Market Data', 'Circulars'] },
  { name: 'BSE India', baseUrl: 'https://www.bseindia.com', categories: ['Corporate Action', 'Market Data', 'Notices'] },
  { name: 'RBI', baseUrl: 'https://www.rbi.org.in', categories: ['RBI Policy', 'Regulation', 'Economic Data'] },
  { name: 'SEBI', baseUrl: 'https://www.sebi.gov.in', categories: ['SEBI Regulation', 'Circulars', 'Enforcement'] },
];

// Realistic Indian stock market news templates
const newsTemplates = [
  // Positive templates
  { template: '{company} Q{qtr} results: Net profit surges {pct}% to Rs {amt} crore, beats estimates', sentiment: 'positive', category: 'Earnings' },
  { template: '{company} shares jump {pct}% after strong Q{qtr} earnings show', sentiment: 'positive', category: 'Markets' },
  { template: 'RBI keeps repo rate unchanged at {rate}%, maintains accommodative stance', sentiment: 'positive', category: 'RBI Policy' },
  { template: '{company} announces Rs {amt} crore buyback at Rs {price} per share', sentiment: 'positive', category: 'Corporate Action' },
  { template: '{company} secures Rs {amt} crore order from {client}', sentiment: 'positive', category: 'Corporate' },
  { template: 'FIIs turn net buyers, infuse Rs {amt} crore in Indian markets', sentiment: 'positive', category: 'Markets' },
  { template: '{sector} sector outlook upgraded by {brokerage}, sees {pct}% upside', sentiment: 'positive', category: 'Sector News' },
  { template: 'India GDP growth accelerates to {pct}% in Q{qtr}', sentiment: 'positive', category: 'Economic Data' },
  { template: '{company} to acquire {target} for Rs {amt} crore in strategic move', sentiment: 'positive', category: 'Mergers & Acquisitions' },
  { template: 'Government approves {pct}% FDI in {sector} sector', sentiment: 'positive', category: 'Government Policy' },
  { template: '{company} launches new product line, expects {pct}% revenue boost', sentiment: 'positive', category: 'Corporate' },
  { template: 'SEBI relaxes norms for {category}, market participants cheer', sentiment: 'positive', category: 'SEBI Regulation' },
  { template: '{company} dividend: Board recommends {pct}% payout for FY{yr}', sentiment: 'positive', category: 'Corporate Action' },
  { template: 'Auto sales surge in {month}: {company} records {pct}% growth', sentiment: 'positive', category: 'Sector News' },
  { template: '{company} bags mega contract worth Rs {amt} crore from government', sentiment: 'positive', category: 'Corporate' },
  { template: 'PLI scheme for {sector}: {company} selected as beneficiary', sentiment: 'positive', category: 'Government Policy' },
  { template: '{company} margin expansion drives strong Q{qtr} performance', sentiment: 'positive', category: 'Earnings' },
  { template: 'Credit growth at {pct}% as banks see robust loan demand', sentiment: 'positive', category: 'Sector News' },
  { template: '{company} partners with {partner} to expand in {market}', sentiment: 'positive', category: 'Corporate' },
  { template: 'GST collections hit record high of Rs {amt} crore in {month}', sentiment: 'positive', category: 'Economic Data' },

  // Negative templates
  { template: '{company} Q{qtr} profit plunges {pct}% to Rs {amt} crore, misses estimates', sentiment: 'negative', category: 'Earnings' },
  { template: '{company} shares tank {pct}% after disappointing earnings', sentiment: 'negative', category: 'Markets' },
  { template: 'RBI hikes repo rate by {bps} bps to {rate}%, loans to get costlier', sentiment: 'negative', category: 'RBI Policy' },
  { template: 'SEBI imposes Rs {amt} crore penalty on {company} for {violation}', sentiment: 'negative', category: 'SEBI Regulation' },
  { template: 'FIIs pull out Rs {amt} crore from Indian markets amid global concerns', sentiment: 'negative', category: 'Markets' },
  { template: '{company} delays {project} launch, shares fall {pct}%', sentiment: 'negative', category: 'Corporate' },
  { template: 'Inflation spikes to {pct}% in {month}, above RBI target', sentiment: 'negative', category: 'Economic Data' },
  { template: '{company} reports NPA surge to {pct}% in Q{qtr}', sentiment: 'negative', category: 'Earnings' },
  { template: 'Crude oil prices jump {pct}%, Indian rupee under pressure', sentiment: 'negative', category: 'Commodities' },
  { template: '{company} promoters pledge additional {pct}% stake', sentiment: 'negative', category: 'Corporate' },
  { template: 'Government bans export of {commodity}, {sector} stocks hit', sentiment: 'negative', category: 'Government Policy' },
  { template: '{company} faces CBI/ED probe in {case} case', sentiment: 'negative', category: 'Corporate' },
  { template: 'Auto sales decline {pct}% in {month} amid weak demand', sentiment: 'negative', category: 'Sector News' },
  { template: '{brokerage} downgrades {company} to underperform, cuts target price', sentiment: 'negative', category: 'Markets' },
  { template: 'I-T raids at {company} premises in {city}', sentiment: 'negative', category: 'Corporate' },
  { template: 'Rupee falls to record low of {rate} against US dollar', sentiment: 'negative', category: 'Currency' },
  { template: '{company} workers go on strike, production hit', sentiment: 'negative', category: 'Corporate' },
  { template: 'Global markets sell-off: {pct}% drop in {index} triggers panic', sentiment: 'negative', category: 'Global Markets' },
  { template: '{company} recalls {product} over safety concerns', sentiment: 'negative', category: 'Corporate' },
  { template: 'Margin pressure weighs on {company} Q{qtr} results', sentiment: 'negative', category: 'Earnings' },

  // Neutral templates
  { template: '{company} to announce Q{qtr} results on {date}', sentiment: 'neutral', category: 'Earnings' },
  { template: 'RBI MPC meeting begins, decision on {date}', sentiment: 'neutral', category: 'RBI Policy' },
  { template: '{company} board meeting scheduled for {date}', sentiment: 'neutral', category: 'Corporate' },
  { template: 'NSE, BSE announce trading holiday on {holiday}', sentiment: 'neutral', category: 'Market Data' },
  { template: '{company} appoints {person} as new MD & CEO', sentiment: 'neutral', category: 'Corporate' },
  { template: 'SEBI issues consultation paper on {topic}', sentiment: 'neutral', category: 'SEBI Regulation' },
  { template: '{company} files DRHP with SEBI for Rs {amt} crore IPO', sentiment: 'neutral', category: 'IPO' },
  { template: 'Market expected to remain range-bound this week', sentiment: 'neutral', category: 'Markets' },
  { template: '{company} to consider fund raising via {mode}', sentiment: 'neutral', category: 'Corporate' },
  { template: 'Economists mixed on RBI rate action ahead of MPC', sentiment: 'neutral', category: 'RBI Policy' },
  { template: '{sector} players meet government officials on {issue}', sentiment: 'neutral', category: 'Sector News' },
  { template: '{company} announces change in statutory auditor', sentiment: 'neutral', category: 'Corporate' },
  { template: 'BSE, NSE add {company} to F&O ban list for {date}', sentiment: 'neutral', category: 'Market Data' },
  { template: '{company} AGM scheduled for {date}, key resolutions listed', sentiment: 'neutral', category: 'Corporate' },
  { template: 'India trade deficit narrows to $ {amt} billion in {month}', sentiment: 'neutral', category: 'Economic Data' },
  { template: '{company} divests {pct}% stake in {subsidiary}', sentiment: 'neutral', category: 'Corporate' },
  { template: 'SEBI approves revised listing norms for {category}', sentiment: 'neutral', category: 'SEBI Regulation' },
  { template: 'RBI releases discussion paper on {topic}', sentiment: 'neutral', category: 'RBI Policy' },
  { template: '{brokerage} initiates coverage on {company} with neutral rating', sentiment: 'neutral', category: 'Markets' },
  { template: '{company} announces bonus shares in {ratio}', sentiment: 'neutral', category: 'Corporate Action' },
];

const companies = [
  'Reliance Industries', 'TCS', 'HDFC Bank', 'Infosys', 'ICICI Bank', 'SBI',
  'Bharti Airtel', 'ITC', 'Kotak Mahindra Bank', 'L&T', 'Axis Bank', 'Hindustan Unilever',
  'Maruti Suzuki', 'Sun Pharma', 'Tata Motors', 'Wipro', 'HCL Tech', 'UltraTech Cement',
  'Asian Paints', 'Bajaj Finance', 'ONGC', 'NTPC', 'Power Grid', 'Tata Steel',
  'Coal India', 'IndusInd Bank', 'JSW Steel', 'Adani Enterprises', 'Adani Ports',
  'Titan', 'Bajaj Finserv', 'Nestle India', 'Dr Reddy\'s Labs', 'Cipla', 'Divis Labs',
  'Britannia', 'Eicher Motors', 'Hero MotoCorp', 'Grasim Industries', 'Hindalco',
  'Vedanta', 'Shree Cement', 'Dabur', 'Pidilite Industries', 'Siemens', 'Havells',
  'Bandhan Bank', 'Federal Bank', 'IDFC First Bank', 'PNB', 'Bank of Baroda',
];

const sectors = [
  'Banking', 'IT', 'Pharma', 'Automobile', 'Energy', 'Metals', 'FMCG',
  'Telecom', 'Real Estate', 'Infrastructure', 'Chemicals', 'Cement', 'Aviation',
  'Hospitality', 'Retail', 'Media', 'Defense', 'Railways', 'Agriculture',
];

const brokerages = [
  'Morgan Stanley', 'Goldman Sachs', 'CLSA', 'UBS', 'Credit Suisse',
  'Jefferies', 'Nomura', 'Citi', 'HSBC', 'Deutsche Bank', 'Kotak Securities',
  'Motilal Oswal', 'ICICI Securities', 'Sharekhan', 'Angel One', 'IIFL',
];

const months = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

const holidays = [
  'Republic Day', 'Holi', 'Good Friday', 'Eid', 'Diwali', 'Christmas',
  'Independence Day', 'Gandhi Jayanti', 'Muharram', 'Ganesh Chaturthi',
  'Navratri', 'Durga Puja', 'Onam', 'Pongal', 'Baisakhi',
];

function randomItem<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomFloat(min: number, max: number, decimals = 2): number {
  return parseFloat((Math.random() * (max - min) + min).toFixed(decimals));
}

function fillTemplate(template: string): string {
  const replacements: Record<string, string> = {
    '{company}': randomItem(companies),
    '{target}': randomItem(companies),
    '{client}': `${randomItem(['Government of India', 'Indian Railways', 'Indian Army', 'Reliance', 'Tata Group', 'Adani Group', 'BPCL', 'Indian Oil'])}`,
    '{partner}': randomItem(['Google', 'Microsoft', 'Amazon', 'Meta', 'Apple', 'Tata Group', 'Reliance', 'Walmart', 'Samsung']),
    '{sector}': randomItem(sectors),
    '{brokerage}': randomItem(brokerages),
    '{pct}': randomInt(2, 35).toString(),
    '{bps}': randomInt(25, 100).toString(),
    '{amt}': randomInt(50, 50000).toString(),
    '{price}': randomInt(100, 10000).toString(),
    '{rate}': randomFloat(4, 8, 2).toString(),
    '{qtr}': randomInt(1, 4).toString(),
    '{yr}': (2024 + randomInt(0, 1)).toString(),
    '{month}': randomItem(months),
    '{date}': `${randomInt(1, 28)}th ${randomItem(months)}`,
    '{holiday}': randomItem(holidays),
    '{person}': `${randomItem(['Rahul', 'Priya', 'Amit', 'Sneha', 'Vikram', 'Anita', 'Rajesh', 'Kavita', 'Arjun', 'Meera'])} ${randomItem(['Sharma', 'Verma', 'Patel', 'Singh', 'Kumar', 'Reddy', 'Iyer', 'Gupta', 'Das', 'Chatterjee'])}`,
    '{topic}': randomItem(['algorithmic trading', 'dark pools', 'short selling', 'insider trading norms', 'mutual fund regulations', 'IPO grading', 'corporate governance', 'ESG disclosures']),
    '{category}': randomItem(['SMEs', 'REITs', 'InvITs', 'debt securities', 'preferential issues', 'rights issues']),
    '{violation}': randomItem(['insider trading', 'misrepresentation', 'non-disclosure', 'price manipulation', 'KYC violation']),
    '{case}': randomItem(['money laundering', 'corruption', 'fraud', 'tax evasion', 'bribery']),
    '{city}': randomItem(['Mumbai', 'Delhi', 'Bengaluru', 'Hyderabad', 'Chennai', 'Kolkata', 'Pune', 'Ahmedabad']),
    '{project}': randomItem(['new plant', 'expansion project', 'product launch', 'infrastructure project', 'technology upgrade']),
    '{commodity}': randomItem(['rice', 'wheat', 'sugar', 'onion', 'cotton', 'iron ore', 'bauxite']),
    '{product}': randomItem(['vehicles', 'pharmaceuticals', 'electronics', 'food products', 'cosmetics']),
    '{index}': randomItem(['Dow Jones', 'S&P 500', 'Nasdaq', 'FTSE', 'Hang Seng', ' Nikkei']),
    '{mode}': randomItem(['QIP', 'rights issue', 'preferential allotment', 'NCDs', 'bonds']),
    '{issue}': randomItem(['taxation', 'regulation', 'pricing', 'licensing', 'subsidy']),
    '{subsidiary}': randomItem(['subsidiary', 'arm', 'joint venture', 'associate company']),
    '{ratio}': randomItem(['1:1', '1:2', '2:1', '3:1', '1:3']),
    '{market}': randomItem(['US', 'Europe', 'Asia-Pacific', 'Middle East', 'Africa', 'domestic']),
  };

  let result = template;
  for (const [placeholder, value] of Object.entries(replacements)) {
    result = result.split(placeholder).join(value);
  }
  return result;
}

function generateHistoricalCorrelation(sentiment: string, sectors: string[]): Record<string, unknown> {
  const correlation: Record<string, unknown> = {};

  // Generate 1-hour impact data
  correlation.oneHourImpact = sentiment === 'positive'
    ? randomFloat(0.5, 3.5, 2)
    : sentiment === 'negative'
    ? randomFloat(-3.5, -0.5, 2)
    : randomFloat(-0.8, 0.8, 2);

  // Generate 24-hour impact data
  correlation.twentyFourHourImpact = sentiment === 'positive'
    ? randomFloat(1, 6, 2)
    : sentiment === 'negative'
    ? randomFloat(-6, -1, 2)
    : randomFloat(-1.5, 1.5, 2);

  // Generate 7-day impact data
  correlation.sevenDayImpact = sentiment === 'positive'
    ? randomFloat(2, 10, 2)
    : sentiment === 'negative'
    ? randomFloat(-10, -2, 2)
    : randomFloat(-2.5, 2.5, 2);

  // Generate historical accuracy based on similar news
  correlation.historicalAccuracy = randomInt(55, 85);

  // Generate sample size of similar historical events
  correlation.sampleSize = randomInt(12, 150);

  // Generate sector-specific impacts
  const sectorImpacts: Record<string, number> = {};
  for (const sector of sectors) {
    sectorImpacts[sector] = sentiment === 'positive'
      ? randomFloat(0.5, 4, 2)
      : sentiment === 'negative'
      ? randomFloat(-4, -0.5, 2)
      : randomFloat(-1, 1, 2);
  }
  correlation.sectorImpacts = sectorImpacts;

  // Generate volatility index impact
  correlation.volatilityImpact = randomFloat(2, 15, 2);

  // Generate volume impact
  correlation.volumeImpact = randomFloat(10, 80, 2);

  return correlation;
}

export function generateNews(count: number = 30): NewsArticle[] {
  const articles: NewsArticle[] = [];
  const now = new Date();

  for (let i = 0; i < count; i++) {
    const template = randomItem(newsTemplates);
    const source = randomItem(newsSources);
    const headline = fillTemplate(template.template);

    // Generate summary (2-3 sentences)
    const summaryTemplates = [
      `According to ${source.name}, the development is expected to have a significant impact on the market. Analysts are closely monitoring the situation for further cues.`,
      `${source.name} reports that market participants are reacting to the news with cautious optimism. The coming sessions will reveal the full impact.`,
      `Sources familiar with the matter tell ${source.name} that the implications could be far-reaching. Technical indicators suggest continued interest.`,
      `In an exclusive report by ${source.name}, the news has caught the attention of institutional investors. Brokers have issued advisory notes to clients.`,
      `${source.name} analysis indicates that this could set a trend for the coming weeks. Sector-specific reactions are being observed across the board.`,
    ];
    const summary = fillTemplate(randomItem(summaryTemplates));

    // Published time: random within last 30 minutes, spread out
    const minutesAgo = randomInt(0, 1800); // Spread over 30 hours for variety
    const publishedAt = new Date(now.getTime() - minutesAgo * 60 * 1000);

    articles.push({
      headline,
      summary,
      source: source.name,
      sourceUrl: source.baseUrl,
      category: template.category,
      publishedAt,
    });
  }

  // Sort by published date (newest first)
  return articles.sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
}

export interface ProcessedNews {
  headline: string;
  summary: string;
  source: string;
  sourceUrl: string;
  category: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  sentimentScore: number;
  sentimentConfidence: number;
  impactScore: number;
  sectorsAffected: string[];
  stocksAffected: string[];
  historicalCorrelation: Record<string, unknown>;
  publishedAt: Date;
}

export function processNews(articles: NewsArticle[]): ProcessedNews[] {
  return articles.map(article => {
    const sentiment = analyzeSentiment(article.headline, article.summary);
    const sectors = identifySectors(article.headline, article.summary);
    const stocks = identifyStocks(article.headline, article.summary);
    const impactScore = calculateImpactScore(sentiment, article.category);
    const historicalCorrelation = generateHistoricalCorrelation(sentiment.sentiment, sectors);

    return {
      ...article,
      sentiment: sentiment.sentiment,
      sentimentScore: sentiment.score,
      sentimentConfidence: sentiment.confidence,
      impactScore,
      sectorsAffected: sectors,
      stocksAffected: stocks,
      historicalCorrelation,
    };
  });
}

export function generateCorrelationTrendData(days: number = 30): Array<{
  date: string;
  newsVolume: number;
  positivePct: number;
  negativePct: number;
  neutralPct: number;
  avgImpact: number;
  marketChange: number;
}> {
  const data = [];
  const today = new Date();

  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);

    const newsVolume = randomInt(40, 120);
    const positiveCount = randomInt(15, Math.floor(newsVolume * 0.6));
    const negativeCount = randomInt(10, Math.max(10, newsVolume - positiveCount - 5));
    const neutralCount = Math.max(0, newsVolume - positiveCount - negativeCount);

    const marketChange = randomFloat(-2.5, 2.8, 2);
    const avgImpact = randomFloat(20, 65, 2);

    data.push({
      date: date.toISOString().split('T')[0],
      newsVolume,
      positivePct: Math.round((positiveCount / newsVolume) * 100),
      negativePct: Math.round((negativeCount / newsVolume) * 100),
      neutralPct: Math.round((neutralCount / newsVolume) * 100),
      avgImpact,
      marketChange,
    });
  }

  return data;
}

export function generateSectorPerformanceData(): Array<{
  sector: string;
  newsCount: number;
  positiveSentiment: number;
  avgImpact: number;
  priceChange: number;
  correlation: number;
}> {
  return sectors.slice(0, 15).map(sector => {
    const newsCount = randomInt(5, 45);
    const positiveSentiment = randomInt(25, 78);
    const avgImpact = randomFloat(25, 72, 2);
    const priceChange = randomFloat(-4.5, 5.2, 2);
    const correlation = randomFloat(0.3, 0.92, 2);

    return {
      sector,
      newsCount,
      positiveSentiment,
      avgImpact,
      priceChange,
      correlation,
    };
  });
}

export function generateSentimentDistribution(): Array<{
  range: string;
  count: number;
}> {
  return [
    { range: '-1.0 to -0.8', count: randomInt(2, 10) },
    { range: '-0.8 to -0.6', count: randomInt(5, 18) },
    { range: '-0.6 to -0.4', count: randomInt(8, 25) },
    { range: '-0.4 to -0.2', count: randomInt(12, 30) },
    { range: '-0.2 to 0.0', count: randomInt(15, 35) },
    { range: '0.0 to 0.2', count: randomInt(15, 35) },
    { range: '0.2 to 0.4', count: randomInt(12, 30) },
    { range: '0.4 to 0.6', count: randomInt(8, 25) },
    { range: '0.6 to 0.8', count: randomInt(5, 18) },
    { range: '0.8 to 1.0', count: randomInt(2, 10) },
  ];
}

export function generateTopMoversData(): Array<{
  symbol: string;
  name: string;
  sector: string;
  priceChange: number;
  newsCount: number;
  sentimentScore: number;
  correlation: number;
}> {
  const movers = companies.slice(0, 20).map(name => {
    const symbol = name.replace(/[^A-Z]/g, '').slice(0, 10);
    const sector = randomItem(sectors);
    const priceChange = randomFloat(-8, 8, 2);
    const newsCount = randomInt(1, 12);
    const sentimentScore = randomFloat(-0.9, 0.9, 2);
    const correlation = randomFloat(0.25, 0.95, 2);

    return {
      symbol,
      name,
      sector,
      priceChange,
      newsCount,
      sentimentScore,
      correlation,
    };
  });

  return movers.sort((a, b) => Math.abs(b.priceChange) - Math.abs(a.priceChange));
}
