// Sentiment analysis for Indian stock market news
// Uses keyword-based approach with financial domain vocabulary

interface SentimentResult {
  sentiment: 'positive' | 'negative' | 'neutral';
  score: number;
  confidence: number;
}

const positiveKeywords = [
  { word: 'surge', weight: 2 }, { word: 'soar', weight: 2 }, { word: 'rally', weight: 2 },
  { word: 'gain', weight: 1.5 }, { word: 'rise', weight: 1 }, { word: 'jump', weight: 1.5 },
  { word: 'boost', weight: 1.5 }, { word: 'growth', weight: 1.5 }, { word: 'profit', weight: 1.5 },
  { word: 'record high', weight: 2.5 }, { word: 'outperform', weight: 2 }, { word: 'upgrade', weight: 1.5 },
  { word: 'buy', weight: 1 }, { word: 'bullish', weight: 2 }, { word: 'optimistic', weight: 1.5 },
  { word: 'strong', weight: 1 }, { word: 'exceed', weight: 1.5 }, { word: 'beat estimates', weight: 2 },
  { word: 'positive', weight: 1 }, { word: 'improve', weight: 1 }, { word: 'recovery', weight: 1.5 },
  { word: 'expansion', weight: 1.5 }, { word: 'approval', weight: 1 }, { word: 'launch', weight: 0.5 },
  { word: 'partnership', weight: 1 }, { word: 'acquisition', weight: 0.5 }, { word: 'merger', weight: 0.5 },
  { word: 'dividend', weight: 1 }, { word: 'bonus', weight: 1 }, { word: 'split', weight: 0.5 },
  { word: 'buyback', weight: 1.5 }, { word: 'investment', weight: 0.5 }, { word: 'funding', weight: 0.5 },
  { word: 'ipo', weight: 0.5 }, { word: 'listing', weight: 0.5 }, { word: 'green', weight: 1 },
  { word: 'upside', weight: 1.5 }, { word: 'momentum', weight: 1 }, { word: 'breakout', weight: 1.5 },
  { word: 'support', weight: 0.5 }, { word: 'rebound', weight: 1.5 }, { word: 'climb', weight: 1 },
  { word: 'advance', weight: 1 }, { word: 'appreciate', weight: 1 }, { word: 'expand', weight: 1 },
  { word: 'favorable', weight: 1 }, { word: 'encouraging', weight: 1 }, { word: 'promising', weight: 1 },
  { word: 'robust', weight: 1.5 }, { word: 'stellar', weight: 2 }, { word: 'impressive', weight: 1.5 },
  { word: 'remarkable', weight: 1.5 }, { word: 'outstanding', weight: 2 }, { word: 'excellent', weight: 1.5 },
  { word: 'cut tax', weight: 1.5 }, { word: 'tax cut', weight: 1.5 }, { word: 'rate cut', weight: 2 },
  { word: 'interest rate cut', weight: 2 }, { word: 'rbi cut', weight: 2 }, { word: 'sebi approval', weight: 1 },
  { word: 'policy support', weight: 1.5 }, { word: 'government push', weight: 1 }, { word: 'incentive', weight: 1 },
  { word: 'subsidy', weight: 0.5 }, { word: 'production linked', weight: 1 }, { word: 'pli scheme', weight: 1 },
  { word: 'demand surge', weight: 2 }, { word: 'order book', weight: 1 }, { word: 'new orders', weight: 1 },
  { word: 'capacity expansion', weight: 1.5 }, { word: 'margin improvement', weight: 1.5 },
  { word: 'asset quality', weight: 1 }, { word: 'credit growth', weight: 1 }, { word: 'inflow', weight: 1 },
  { word: 'fii buying', weight: 1.5 }, { word: 'fpi buying', weight: 1.5 }, { word: 'dii buying', weight: 1 },
  { word: 'retail interest', weight: 0.5 }, { word: 'auto sales', weight: 0.5 }, { word: 'gst collection', weight: 0.5 },
  { word: 'gdp growth', weight: 1.5 }, { word: 'industrial output', weight: 1 }, { word: 'manufacturing pmi', weight: 0.5 },
  { word: 'services pmi', weight: 0.5 }, { word: 'employment', weight: 0.5 }, { word: 'job creation', weight: 0.5 },
  { word: 'infrastructure', weight: 0.5 }, { word: 'capex', weight: 1 }, { word: 'capital expenditure', weight: 1 },
  { word: 'debt reduction', weight: 1 }, { word: 'deleveraging', weight: 1 }, { word: 'cash flow', weight: 0.5 },
  { word: 'ebitda', weight: 0.5 }, { word: 'pat', weight: 0.5 }, { word: 'net profit', weight: 1 },
  { word: 'revenue growth', weight: 1 }, { word: 'topline growth', weight: 1 }, { word: 'bottomline growth', weight: 1.5 },
  { word: 'roce', weight: 0.5 }, { word: 'roe', weight: 0.5 }, { word: 'return on equity', weight: 0.5 },
];

const negativeKeywords = [
  { word: 'crash', weight: 3 }, { word: 'plunge', weight: 2.5 }, { word: 'tumble', weight: 2.5 },
  { word: 'slump', weight: 2 }, { word: 'drop', weight: 1.5 }, { word: 'fall', weight: 1.5 },
  { word: 'decline', weight: 1.5 }, { word: 'loss', weight: 2 }, { word: 'bearish', weight: 2 },
  { word: 'sell', weight: 1 }, { word: 'downgrade', weight: 1.5 }, { word: 'pessimistic', weight: 1.5 },
  { word: 'weak', weight: 1 }, { word: 'miss estimates', weight: 2 }, { word: 'negative', weight: 1 },
  { word: 'worsen', weight: 1.5 }, { word: 'recession', weight: 2.5 }, { word: 'inflation', weight: 1 },
  { word: 'rate hike', weight: 2 }, { word: 'interest rate hike', weight: 2 }, { word: 'rbi hike', weight: 2 },
  { word: 'default', weight: 2.5 }, { word: 'bankruptcy', weight: 3 }, { word: 'fraud', weight: 2.5 },
  { word: 'scam', weight: 2 }, { word: 'investigation', weight: 1.5 }, { word: 'raid', weight: 1.5 },
  { word: 'sebi action', weight: 1.5 }, { word: 'penalty', weight: 1.5 }, { word: 'fine', weight: 1 },
  { word: 'lawsuit', weight: 1 }, { word: 'dispute', weight: 0.5 }, { word: 'strike', weight: 1 },
  { word: 'lockout', weight: 1 }, { word: 'shutdown', weight: 1.5 }, { word: 'delay', weight: 0.5 },
  { word: 'shortage', weight: 1 }, { word: 'supply chain', weight: 0.5 }, { word: 'disruption', weight: 1 },
  { word: 'red', weight: 1 }, { word: 'downside', weight: 1.5 }, { word: 'resistance', weight: 0.5 },
  { word: 'sell-off', weight: 2 }, { word: 'capital outflow', weight: 1.5 }, { word: 'fii selling', weight: 1.5 },
  { word: 'fpi selling', weight: 1.5 }, { word: 'dii selling', weight: 1 }, { word: 'outflow', weight: 1 },
  { word: 'currency depreciation', weight: 1 }, { word: 'rupee fall', weight: 1 }, { word: 'current account deficit', weight: 1 },
  { word: 'fiscal deficit', weight: 1 }, { word: 'trade deficit', weight: 1 }, { word: 'job cuts', weight: 1 },
  { word: 'layoffs', weight: 1 }, { word: 'unemployment', weight: 1 }, { word: 'slowdown', weight: 1.5 },
  { word: 'contraction', weight: 1.5 }, { word: 'shrink', weight: 1 }, { word: 'margin pressure', weight: 1.5 },
  { word: 'input cost', weight: 1 }, { word: 'raw material cost', weight: 1 }, { word: 'fuel price', weight: 0.5 },
  { word: 'crude oil', weight: 0.5 }, { word: 'commodity price', weight: 0.5 }, { word: 'power tariff', weight: 0.5 },
  { word: 'tax hike', weight: 1.5 }, { word: 'duty hike', weight: 1 }, { word: 'levy', weight: 0.5 },
  { word: 'ban', weight: 1.5 }, { word: 'restriction', weight: 1 }, { word: 'export ban', weight: 1.5 },
  { word: 'import duty', weight: 1 }, { word: 'quota', weight: 0.5 }, { word: 'sanction', weight: 1.5 },
  { word: 'geopolitical', weight: 1 }, { word: 'war', weight: 2 }, { word: 'conflict', weight: 1.5 },
  { word: 'tension', weight: 1 }, { word: 'earthquake', weight: 1 }, { word: 'flood', weight: 1 },
  { word: 'drought', weight: 1 }, { word: 'pandemic', weight: 2 }, { word: 'lockdown', weight: 2 },
  { word: 'npa', weight: 1.5 }, { word: 'non-performing', weight: 1.5 }, { word: 'bad loan', weight: 1.5 },
  { word: 'asset quality deterioration', weight: 1.5 }, { word: 'credit risk', weight: 1 }, { word: 'liquidity crisis', weight: 2 },
  { word: 'cash crunch', weight: 1.5 }, { word: 'debt trap', weight: 2 }, { word: 'insolvency', weight: 2.5 },
  { word: 'nclt', weight: 1 }, { word: 'liquidation', weight: 2 }, { word: 'wind up', weight: 1.5 },
  { word: 'delisting', weight: 1.5 }, { word: 'promoter selling', weight: 1.5 }, { word: 'pledge', weight: 1 },
  { word: 'shares pledged', weight: 1.5 }, { word: 'margin call', weight: 2 }, { word: 'stop loss', weight: 0.5 },
  { word: 'circuit filter', weight: 1 }, { word: 'lower circuit', weight: 2 }, { word: 'freeze', weight: 0.5 },
  { word: 'profit booking', weight: 0.5 }, { word: 'correction', weight: 1 }, { word: 'consolidation', weight: 0.5 },
  { word: 'range bound', weight: 0.5 }, { word: 'sideways', weight: 0.5 }, { word: 'lackluster', weight: 0.5 },
  { word: 'dull', weight: 0.5 }, { word: 'subdued', weight: 0.5 }, { word: 'volatile', weight: 0.5 },
  { word: 'volatility', weight: 0.5 }, { word: 'uncertainty', weight: 1 }, { word: 'fear', weight: 1 },
  { word: 'panic', weight: 1.5 }, { word: 'caution', weight: 0.5 }, { word: 'cautious', weight: 0.5 },
  { word: 'worried', weight: 0.5 }, { word: 'concern', weight: 0.5 }, { word: 'risk', weight: 0.5 },
];

const neutralizingPhrases = [
  'may', 'could', 'might', 'expected to', 'likely to', 'rumor', 'rumour',
  'speculation', 'speculated', 'unconfirmed', 'reports suggest', 'sources say',
  'according to sources', 'unverified', 'alleged', 'allegedly', 'claimed',
];

export function analyzeSentiment(headline: string, summary?: string): SentimentResult {
  const text = `${headline} ${summary || ''}`.toLowerCase();
  let positiveScore = 0;
  let negativeScore = 0;
  let matchedPositive = 0;
  let matchedNegative = 0;

  // Check for positive keywords
  for (const keyword of positiveKeywords) {
    if (text.includes(keyword.word)) {
      const occurrences = (text.match(new RegExp(keyword.word, 'g')) || []).length;
      positiveScore += keyword.weight * occurrences;
      matchedPositive += occurrences;
    }
  }

  // Check for negative keywords
  for (const keyword of negativeKeywords) {
    if (text.includes(keyword.word)) {
      const occurrences = (text.match(new RegExp(keyword.word, 'g')) || []).length;
      negativeScore += keyword.weight * occurrences;
      matchedNegative += occurrences;
    }
  }

  // Check for neutralizing phrases that reduce confidence
  let neutralizingFactor = 1;
  for (const phrase of neutralizingPhrases) {
    if (text.includes(phrase)) {
      neutralizingFactor *= 0.7;
    }
  }

  // Calculate net score (-1 to +1)
  const totalScore = positiveScore + negativeScore;
  let netScore = 0;
  if (totalScore > 0) {
    netScore = ((positiveScore - negativeScore) / totalScore) * neutralizingFactor;
  }

  // Determine sentiment
  let sentiment: 'positive' | 'negative' | 'neutral' = 'neutral';
  const threshold = 0.15;

  if (netScore > threshold) {
    sentiment = 'positive';
  } else if (netScore < -threshold) {
    sentiment = 'negative';
  }

  // Calculate confidence based on number of matches and score magnitude
  const matchConfidence = Math.min((matchedPositive + matchedNegative) / 3, 1);
  const scoreConfidence = Math.min(Math.abs(netScore) * 2, 1);
  const confidence = Math.round(((matchConfidence + scoreConfidence) / 2) * 100) / 100;

  return {
    sentiment,
    score: Math.round(netScore * 100) / 100,
    confidence,
  };
}

export function calculateImpactScore(sentiment: SentimentResult, category?: string): number {
  let baseImpact = Math.abs(sentiment.score) * sentiment.confidence * 50;

  // Category-based adjustments
  const categoryWeights: Record<string, number> = {
    'RBI Policy': 1.5,
    'SEBI Regulation': 1.3,
    'Government Policy': 1.4,
    'Earnings': 1.2,
    'Mergers & Acquisitions': 1.3,
    'IPO': 1.1,
    'Commodities': 1.0,
    'Currency': 1.1,
    'Global Markets': 0.9,
    'Sector News': 1.2,
    'Corporate Action': 1.1,
    'Economic Data': 1.2,
    'Politics': 0.8,
  };

  if (category && categoryWeights[category]) {
    baseImpact *= categoryWeights[category];
  }

  return Math.min(Math.round(baseImpact * 100) / 100, 100);
}

export function identifySectors(headline: string, summary?: string): string[] {
  const text = `${headline} ${summary || ''}`.toLowerCase();
  const sectors: string[] = [];

  const sectorKeywords: Record<string, string[]> = {
    'Banking': ['bank', 'nbfc', 'hdfc', 'icici', 'sbi', 'axis', 'kotak', 'indusind', 'rbi', 'lending', 'loan', 'credit', 'npa'],
    'IT': ['it', 'software', 'tech', 'tcs', 'infosys', 'wipro', 'hcl', 'tech mahindra', 'mphasis', 'persistent', 'lti', 'mindtree'],
    'Pharma': ['pharma', 'pharmaceutical', 'drug', 'medicine', 'cipla', 'sun pharma', 'dr reddy', 'lupin', 'aurobindo', 'divis', 'biocon'],
    'Automobile': ['auto', 'car', 'vehicle', 'maruti', 'tata motors', 'mahindra', 'bajaj auto', 'hero moto', 'eicher', 'ashok leyland', 'tvs motor'],
    'Energy': ['energy', 'oil', 'gas', 'power', 'reliance', 'ongc', 'ioc', 'bpcl', 'hpcl', 'ntpc', 'power grid', 'tata power', 'adani green', 'suzlon'],
    'Metals': ['metal', 'steel', 'iron', 'aluminum', 'copper', 'tata steel', 'jsw steel', 'hindalco', 'vedanta', 'coal india', 'nmdc', 'sail'],
    'FMCG': ['fmcg', 'consumer', 'hul', 'hindustan unilever', 'itc', 'nestle', 'britannia', 'dabur', 'marico', 'godrej', 'colgate'],
    'Telecom': ['telecom', 'mobile', 'jio', 'airtel', 'vodafone', 'idea', 'tower', '5g', 'broadband'],
    'Real Estate': ['real estate', 'property', 'housing', 'dlf', 'godrej properties', 'oberoi', 'sobha', 'prestige', 'brigade'],
    'Infrastructure': ['infrastructure', 'construction', 'road', 'highway', 'port', 'airport', 'larsen', 'l&t', 'tata projects', 'irb', 'nhai'],
    'Chemicals': ['chemical', 'fertilizer', 'pesticide', 'tatva chintan', 'deepak', 'atul', 'upl', 'coromandel', 'chambal'],
    'Cement': ['cement', 'ultratech', 'acc', 'ambuja', 'shree cement', 'ramco', 'prism', 'birla'],
    'Aviation': ['aviation', 'airline', 'aircraft', 'indigo', 'spicejet', 'go first', 'air india', 'vistara'],
    'Hospitality': ['hotel', 'hospitality', 'leisure', 'taj', 'leela', 'oberoi hotels', 'eih', 'mahindra holidays'],
    'Retail': ['retail', 'shopping', 'mall', 'dmart', 'avenue supermarts', 'trent', 'westside', 'pantaloons', 'reliance retail'],
    'Media': ['media', 'entertainment', 'broadcast', 'zee', 'sun tv', 'pvr', 'inox', 'network18', 'tv18', 'times'],
  };

  for (const [sector, keywords] of Object.entries(sectorKeywords)) {
    for (const keyword of keywords) {
      if (text.includes(keyword)) {
        if (!sectors.includes(sector)) {
          sectors.push(sector);
        }
        break;
      }
    }
  }

  return sectors;
}

export function identifyStocks(headline: string, summary?: string): string[] {
  const text = `${headline} ${summary || ''}`.toLowerCase();
  const stocks: string[] = [];

  const stockKeywords: Record<string, string[]> = {
    'RELIANCE': ['reliance', 'ril', 'jio'],
    'TCS': ['tcs', 'tata consultancy'],
    'HDFCBANK': ['hdfc bank', 'hdfcbank'],
    'INFY': ['infosys', 'infy'],
    'ICICIBANK': ['icici bank', 'icicibank'],
    'SBIN': ['state bank', 'sbi', 'sbin'],
    'BHARTIARTL': ['bharti airtel', 'airtel', 'bhartiartl'],
    'ITC': ['itc limited', ' itc '],
    'KOTAKBANK': ['kotak mahindra', 'kotak bank', 'kotak'],
    'LT': ['larsen & toubro', 'l&t', 'larsen and toubro'],
    'AXISBANK': ['axis bank', 'axisbank'],
    'HINDUNILVR': ['hindustan unilever', 'hul', 'hindunilvr'],
    'MARUTI': ['maruti suzuki', 'maruti'],
    'SUNPHARMA': ['sun pharma', 'sun pharmaceutical', 'sunpharma'],
    'TATAMOTORS': ['tata motors', 'tatamotors'],
    'WIPRO': ['wipro'],
    'HCLTECH': ['hcl tech', 'hcl technologies', 'hcltech'],
    'ULTRACEMCO': ['ultratech cement', 'ultracemco'],
    'ASIANPAINT': ['asian paints', 'asianpaint'],
    'BAJFINANCE': ['bajaj finance', 'bajfinance'],
    'ONGC': ['ongc', 'oil and natural gas'],
    'HDFCLIFE': ['hdfc life', 'hdfclife'],
    'SBILIFE': ['sbi life', 'sbilife'],
    'NTPC': ['ntpc'],
    'POWERGRID': ['power grid', 'powergrid'],
    'TATASTEEL': ['tata steel', 'tatasteel'],
    'COALINDIA': ['coal india', 'coalindia'],
    'INDUSINDBK': ['indusind bank', 'indusind'],
    'JSWSTEEL': ['jsw steel', 'jswsteel'],
    'ADANIENT': ['adani enterprises', 'adanient'],
    'ADANIPORTS': ['adani ports', 'adaniports', 'apsez'],
    'ADANIGREEN': ['adani green', 'adanigreen'],
    'ADANIPOWER': ['adani power', 'adanipower'],
    'TITAN': ['titan company', 'titan'],
    'BAJAJFINSV': ['bajaj finserv', 'bajajfinsv'],
    'NESTLEIND': ['nestle india', 'nestleind', 'nestle'],
    'DRREDDY': ['dr reddy', 'drreddy'],
    'CIPLA': ['cipla'],
    'DIVISLAB': ['divis lab', 'divislab'],
    'BRITANNIA': ['britannia'],
    'EICHERMOT': ['eicher motors', 'eichermot'],
    'HEROMOTOCO': ['hero motocorp', 'heromotoco', 'hero honda'],
    'GRASIM': ['grasim industries', 'grasim'],
    'HINDALCO': ['hindalco'],
    'VEDL': ['vedanta', 'vedl'],
    'SHREECEM': ['shree cement', 'shreecem'],
    'DABUR': ['dabur'],
    'PIDILITIND': ['pidilite industries', 'pidilite'],
    'SIEMENS': ['siemens'],
    'HAVELLS': ['havells'],
    'ABB': ['abb india', ' abb '],
    'AMBUJACEM': ['ambuja cement', 'ambujacem'],
    'ACC': [' acc limited', ' acc cement'],
    'BOSCHLTD': ['bosch', 'boschltd'],
    'MARICO': ['marico'],
    'BANDHANBNK': ['bandhan bank', 'bandhan'],
    'FEDERALBNK': ['federal bank', 'federalbnk'],
    'IDFCFIRSTB': ['idfc first bank', 'idfcfirst'],
    'PNB': ['punjab national bank', ' pnb '],
    'BANKBARODA': ['bank of baroda', 'bob', 'bankbaroda'],
    'CANBK': ['canara bank', 'canbk'],
    'UNIONBANK': ['union bank', 'unionbank'],
    'IOB': ['indian overseas bank', ' iob '],
    'INDIANB': ['indian bank', 'indianb'],
    'UCOBANK': ['uco bank', 'ucobank'],
    'PSB': ['public sector bank', 'psu bank'],
  };

  for (const [symbol, keywords] of Object.entries(stockKeywords)) {
    for (const keyword of keywords) {
      if (text.includes(keyword)) {
        if (!stocks.includes(symbol)) {
          stocks.push(symbol);
        }
        break;
      }
    }
  }

  return stocks.slice(0, 10); // Limit to top 10 stocks
}
